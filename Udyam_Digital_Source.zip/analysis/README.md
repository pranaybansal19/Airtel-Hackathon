# Notebook guide

Run these in order using a Python kernel with the development requirements installed:

1. 01_EDA.ipynb â€” funnel, segment economics, quality checks and charts.
2. 02_Catalogue_Engine.ipynb â€” original pricing prototype; backend now extends its site handling.
3. 03_KYC_Audit.ipynb â€” manual inspection of 12 applicant sets.
4. 04_Backend_Walkthrough.ipynb â€” actual quote API and revisions.
5. 05_End_to_End_Verification.ipynb â€” real Windows OCR and complete simulated journey.
6. 06_Local_AI_and_Corrections.ipynb â€” installed local Ollama model and explicit OCR correction.

All six have executed in native Jupyter and contain saved outputs. Notebooks 05/06 require Windows OCR; 06 additionally requires the installed qwen2.5:1.5b model and running Ollama. Earlier sandbox kernel-startup limitations were resolved by running outside the restricted execution environment.

The legacy aggregate exporter is in ../tools/analyze.py. Runtime backend Python modules are necessary for the server; notebooks are the analysis and debugging interface.

Read ../README.md for setup, assumptions, measured limitations and future work.

7. 07_Revision_Verification.ipynb — executed current Tesseract/decision audit. Earlier notebooks retain historical outputs; old operator-action cells need separate operator credentials when rerun.

Linux acceptance evidence: tesseract_results_linux.csv and tesseract_journey_results_linux.json. Windows results remain separate. All specimens are synthetic; do not interpret documentary clearance as real identity or authority verification.
