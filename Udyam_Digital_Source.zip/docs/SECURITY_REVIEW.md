# Current revision

Separate X-Operator-Token authorization now rejects customer-only approval/scheduling/activation. Tesseract is the default and uses image memory pipes; the legacy Windows adapter alone uses temporary files. Direct GST resolution is now 3/12 on Windows and 4/12 on Ubuntu. K02/K12 pass on Windows, and K02/K03/K12 pass on Ubuntu; this is not identity/authority verification. See PRIVACY_NOTE.md and REVISION_REVIEW.md.

The following original control inventory remains relevant except where superseded above.

# Security review against the problem statement

The supplied case asks for consent, purpose limitation and data minimisation, plus a one-page privacy/security design note. This is an implementation review, not a legal compliance certification. All supplied records are synthetic.

| Requirement or concern | Implemented control and evidence | Limit |
|---|---|---|
| Consent | `backend/journey.py`: current notice version and affirmative consent required to create a journey; timestamp recorded | No production consent-management service |
| Purpose limitation | Notice limits processing to synthetic business checks and a demo order; uploaded KYC data is not passed to the AI adapter | Free-text business descriptions are sent locally to Ollama as typed; personal-data filtering is not automatic |
| Data minimisation | Quotes store computed results rather than raw GST input; identifier responses are masked; private OCR comparison text is omitted from public responses | Synthetic source data and research notebook outputs remain in the repository intentionally |
| Retention | Temporary OCR images deleted in finally cleanup; document evidence removed on approval/withdrawal or after 30 days | Expiry is checked on startup/access, not continuously; crashes may leave files; review notes/events remain until withdrawal |
| Withdrawal | Token-protected DELETE removes the journey and linked quotes | File/database deletion is not secure erasure or backup deletion |
| Journey access | Random secret token; SHA-256 token hash stored server-side; constant-time comparison | Token lives in browser localStorage; no customer accounts or staff roles; quote/registry routes lack account authorization |
| Local processing | Server binds to 127.0.0.1; Ollama uses fixed loopback URL; OCR runs through Windows locally | Localhost is a deployment restriction, not full authentication or encryption |
| Input validation | Pydantic models reject extra fields and invalid values; server recalculates quotes; image format/size/dimensions checked | No comprehensive adversarial security testing or public-service rate limits |
| Database queries | SQLite statements bind parameters instead of inserting user input into SQL strings | No application-level database encryption |
| Browser output | Dynamic text uses textContent or HTML escaping; responses use Cache-Control: no-store | No full browser security hardening or penetration test |
| Logging | Default launcher disables HTTP access logs; validation responses omit rejected input values | Free-text notes require care; no comprehensive log-redaction infrastructure |
| AI trust | Model output is schema-validated and user-confirmed; deterministic rules control eligibility and pricing | Prompt instructions alone do not guarantee accurate extraction; model evaluation is small |
| KYC integrity | Format/checksum and synthetic registry status checks; explicit corrections retain original OCR concerns; review required | OCR is not authenticity verification; 0/12 direct GST resolution; signing authority unavailable in registry |

## Verification

37 automated tests cover functional controls including consent, token access, expiry, deletion, invalid inputs, quote integrity and transitions. They are not a penetration test or legal assessment. Real OCR and small local-AI evaluations are separately recorded in notebooks 05/06.

## Before real customer deployment

Add authenticated customer/staff roles, secure sessions, HTTPS, encryption/key management, authorized registry integrations, scheduled cleanup and crash recovery, rate limits/upload hardening, security monitoring, dependency review and independent security testing. Review the applicable legal obligations and retention policy with qualified owners before making any compliance claim.

## Simple explanation for judges

We ask permission before document processing, explain its purpose, process documents locally, expose only necessary fields and delete evidence under a stated retention policy. Access tokens protect journeys and server-side rules validate input. These demonstrate privacy-conscious design; production identity, authorization, encryption and operational controls remain future work.
