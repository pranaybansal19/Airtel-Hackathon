# Historical implementation record — superseded by root README

# Udyam Digital — implementation and verification guide

This repository turns the supplied hackathon case into a local prototype for small-business discovery, quoting, business-document checks and order tracking. This README is the current source of truth: it explains what exists, how it works, how to verify it and what remains unfinished. All source customer data is fictional.

## 1. What problem are we solving?

The case describes a slow, sales-led acquisition journey: visits, confusing quotes, physical paperwork and repeated status calls. Only 368 of 5,000 supplied leads activate (7.36%). Our approach is a mobile-friendly self-service journey, with assisted review where evidence or business requirements need it.

The first customer is a professional office such as a clinic or CA firm. Multi-site businesses are the next assisted pilot. Micro businesses can use cheaper no-GST products. Discovery and onboarding can be completed digitally; physical installation is not instant.

## 2. Current status — working versus simulated

| Component | What exists now | Limits |
|---|---|---|
| EDA | Reproducible notebooks, segment/funnel/channel outputs, documented interpretation | Synthetic observational data; no causal lift or real unit-economics claims |
| Interface | Discovery, editable quote, consent/upload and tracker screens | English plus Hindi headings/labels/recommendation; not full localization |
| Advisor | Structured local-Ollama extraction adapter plus guided form; rules select bundles | Ollama qwen2.5:1.5b installed and tested locally; current setup is captured but does not drive a detailed migration strategy |
| Catalogue | Tier, employee/site minimums, active GST, positive quantities, per-site dependencies | No live serviceability, discounts or tax rules |
| Quote | Itemised prices, setup, individual contracts, preview, SQLite saving and versioned API revisions | UI saves new quote snapshots; API supports versioned PATCH; no payment |
| Registries | Mock GST/Udyam APIs and GST checksum validation | CSV data, not government services; no signatory-authority field |
| Smart KYC | Actual Windows OCR, field candidates, GST/status/name/date checks, cross-document checks and review routing | OCR errors possible; no confidence score; signatory authority needs human evidence |
| Consent/privacy | Versioned notice, token-gated uploads, temporary originals deleted, evidence retention/deletion | Local prototype access model; no production roles/encryption; cleanup is access-triggered |
| Tracker | Persisted events, per-product dates, assistance handoff | Review approval, serviceability, scheduling and activation are explicitly simulated |
| Business deliverables | Editable ten-slide presentation, architecture/privacy PDFs, narrated 2m42s walkthrough and clean source archive | Captured-screen walkthrough; operational actions remain simulated |

## 3. Start the application

Tested on this Windows machine with Python 3.14. Windows OCR needs the English OCR language pack. The rest of the API can run without OCR on other platforms; image processing returns an explicit unavailable response there.

```powershell
# Run from the repository root
python -m pip install --target .dependencies -r requirements.txt
python -m backend.run
```

Open **http://127.0.0.1:8000/** for the app and **http://127.0.0.1:8000/docs** for the interactive API. The launcher binds only to localhost and disables request access logs. It does not publish a website. Stop it with Ctrl+C.

For notebooks/tests, install development packages into your selected Python environment:

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q --tb=short
```

Notebook kernels must use the same environment. `runtime/` contains generated local databases and temporary verification files and is ignored by Git. `.dependencies/` is also ignored. Do not commit credentials, runtime databases or real customer files.

## 4. Local GenAI setup

The selected approach is **local Ollama**, with no cloud API key. The application calls the fixed loopback endpoint `http://127.0.0.1:11434/api/chat`, requests JSON-schema output and validates it before returning it. It sends business descriptions only; uploaded KYC images/text never enter this adapter.

```powershell
# After installing Ollama from its official distribution
ollama pull qwen2.5:1.5b
# If the Ollama service is not running, run ollama serve in another terminal
$env:UDYAM_OLLAMA_MODEL='qwen2.5:1.5b'
python -m backend.run
```

Expand “Describe your business with local AI”, enter a business description, and select “Extract details”. Confirm the extracted numbers before requesting a bundle. Unknown values should remain unfilled; the model is not trusted to select prices or satisfy eligibility. If the service is unavailable or output fails validation, the app explicitly falls back to guided-form mode.

The small model is chosen to keep local resource use manageable. It is not assumed to have production-quality multilingual accuracy. Additional acceptance tests are needed before claiming broad regional-language support. Official structured-output reference: https://github.com/ollama/ollama/blob/main/docs/api.md ; model reference: https://ollama.com/library/qwen2.5/tags .

## 5. What was done, in order

1. Read the case statement and dataset README. Identified the four mandatory modules and submission requirements.
2. Profiled 5,000 leads and 25 products. Computed cumulative funnel, segment economics, channel/language/GST comparisons, blankness and registry joins. Source CSVs were not modified.
3. Documented the first professional-office journey, example bundles, error paths and pilot hypotheses.
4. Converted exploratory work into Jupyter notebooks. The original `tools/analyze.py` is retained only as a legacy export utility.
5. Inspected all 47 images for 12 applicants and wrote an evidence-based review manifest. This manual audit is distinct from automated OCR.
6. Implemented strict backend models, catalogue rules, checksum validation, lookup APIs and SQLite quote versions. Added meaningful behaviour tests.
7. Built the four customer screens and connected them to the real API. Added cheaper alternatives, add/remove quantities, budget warnings, quote persistence and return-to-journey support.
8. Integrated Windows local OCR, consent, masked candidate display, review routing, retention and deletion. Uncertain OCR is not silently corrected.
9. Implemented a persistent demo order state machine, partner handoff indicator and per-product estimates. Operator simulations require explicit notes and valid preceding states.
10. Added the Ollama structured-intake adapter and prepared architecture, privacy, business-case and demo documentation. See verification notes for what was actually exercised.

## 6. Data findings that drive the design

| Segment | Leads | Activation | Median monthly bundle | Observed 6-month churn |
|---|---:|---:|---:|---:|
| Micro retail/services | 2,709 | 4.06% | Rs 2,470 | 22.73% |
| Professional offices | 1,247 | 11.07% | Rs 6,575 | 13.77% |
| Small multi-site | 755 | 10.99% | Rs 28,080 | 10.84% |
| Small manufacturers | 289 | 12.80% | Rs 15,910 | 8.11% |

Professional offices have the lowest segment CAC (Rs 10,694.71). Overall blended CAC is Rs 15,053.37, calculated as all lead acquisition spending / activations. Average activation is 17.62 days; chase calls average 3.01 among activated customers.

Largest proportional loss: needs assessed -> quote accepted (1,113 of 1,974, or 56.38%). Largest absolute loss: before contact (1,594). All 3,534 populated lead GSTINs join the registry, but 167 are Cancelled and 101 Suspended. Check status as well as existence.

Follow-up calls correlate with poorer outcomes; causality is not established. Mean 0–10 survey rating is not NPS; standard NPS is % ratings 9–10 minus % ratings 0–6. The supplied future six-month outcome labels are retrospective synthetic exercise labels; do not use them as predictive inputs or claim they matured by the KYC reference date.

## 7. How recommendation and pricing work

- Discovery collects employee count, sites/tier, segment, requested email/device counts, resilience and budget. UI uses one tier for all locations; API supports individual tiers.
- Micro starter uses P01; other initial segments use P02. Email P16 and endpoint protection P20 use requested quantities; resilience P09 is per selected site. Manufacturers/complex multi-site cases are flagged for assisted assessment.
- Catalogue rules validate every preview and saved quote. Active GST is looked up server-side; a caller cannot set `gst_status=Active`.
- Products with connectivity prerequisites must have them at the same selected site. Per-site products use one unit per site. Other units (line, user, device etc.) use explicit quantities.
- Price policy is catalogue minimum with no invented discounts. Setup is assumed per purchased unit. Taxes are unspecified and excluded. Each line keeps its own minimum contract.
- A cheaper 100-Mbps alternative is offered for the 300-Mbps starter. Budget excess is flagged; requested capabilities are not silently removed.
- Reference office: P02 x1 + P16 x5 + P20 x5 = **Rs 2,619/month**, setup zero, 12-month terms. P09 x1 changes this to **Rs 3,118/month**, setup **Rs 1,500**.
- These offers are testable examples, not market-validated pricing or proven savings against historical median bills.

## 8. How document handling works

The user accepts notice version `2026-11-demo-v1` before a journey exists. A random bearer token authorizes journey access; only its hash is stored server-side. The UI retains the token in local storage to resume. Do not share the token.

Uploads are PNG/JPEG, max 6 MB and constrained dimensions. The backend decodes/re-encodes a temporary image, runs Windows OCR and deletes the original temporary file. Extracted private comparison text stays in the journey only until review completion, withdrawal or 30-day expiry. Public responses mask identifier candidates and omit private comparison fields.

Checks include checksum/registry status, legal-name comparison, address consistency, GST/Udyam enterprise-name consistency and address-proof age. KYC date checks use **2026-07-15**, per the dataset README; tracker estimates use the real scheduling date. Exactly 90-day-old proof is allowed; 91 days or a future date routes to review.

OCR may confuse I/1 and O/0. We do not silently substitute characters. All submitted cases go to review because the registry cannot verify signing authority. The demo reviewer can resolve uncertain evidence with an explicit note, but cannot approve known stale/future proof or inactive GST. GST-required products need readable active evidence. A supplied active GST identifier must match the quote’s GST binding when both are available.

Manual audit findings: K01 cancelled GST/blank Udyam; K04 blur; K05 missing Udyam file; K06 altered GSTIN; K07 legal-name discrepancy; K09 cropped proof; K10 signatory differs from lead contact (authority unverified); K11 stale proof. K02/K03/K08/K12 had no obvious issue in manual review, not blanket approval. See the manifest for exact observations and uncertainty.

## 9. How tracking and handoff work

`documents_pending -> review_required -> verified_demo -> scheduled_demo -> activated_demo`

Uploading replacement evidence returns the case to documents_pending. Submission checks required documents. Approval removes extracted evidence. Scheduling creates a product-level estimated date using `typical_install_days`. Invalid jumps are rejected. Assistance requests preserve a queue, reason, time and optional partner reference.

The customer-facing tracker is real persisted application state. The underlying reviewer/serviceability/installation actions are simulated, labelled in the UI and event log. There is no payment, contract signature, real appointment or actual network activation. The prototype has no separate staff authorization layer; demo controls are not suitable for a public deployment.

## 10. Main files and notebooks

| Path | Purpose |
|---|---|
| `analysis/01_EDA.ipynb` | EDA, charts, NPS and date checks |
| `analysis/02_Catalogue_Engine.ipynb` | Original interactive rule prototype; backend supersedes its simpler site handling |
| `analysis/03_KYC_Audit.ipynb` | Manual applicant audit and image inspection |
| `analysis/04_Backend_Walkthrough.ipynb` | Actual lookup/quote APIs and revisions |
| `analysis/05_End_to_End_Verification.ipynb` | Real OCR on 12 GST certificates and actual API journey |
| `analysis/06_Local_AI_and_Corrections.ipynb` | Actual local-model English/Hindi extraction and explicit OCR correction |
| `analysis/kyc_review_manifest.csv` | Evidence-backed manual observations, masked IDs |
| `analysis/ocr_gst_results.csv` | Measured OCR results, generated by notebook 05 |
| `backend/domain.py` | Catalogue arithmetic, prerequisites, registry data and checksum |
| `backend/app.py` | Validated API models and versioned SQLite quotes |
| `backend/advisor.py` | Local AI extraction and deterministic starter recommendation |
| `backend/ocr.py`, `backend/windows_ocr.ps1` | Image validation, local OCR and evidence checks |
| `backend/journey.py` | Consent, tokens, evidence lifecycle, review and demo tracking |
| `frontend/` | Buildless responsive HTML/CSS/JavaScript |
| `tests/` | Repeatable behaviour tests; OCR doubles are labelled in tests |
| `docs/ARCHITECTURE.md` | Mermaid architecture and trust boundaries |
| `docs/PRIVACY_NOTE.md` | Privacy/security design note and limitations |
| `docs/BUSINESS_CASE.md` | Ten-slide business-case content draft |
| `docs/DEMO_SCRIPT.md` | Three-minute recording script |

## 11. How you can verify correctness

1. Run `python -m pytest -q --tb=short`. Tests cover all supplied GST checksums and mutations, malformed/unknown registry IDs, cancelled/suspended status, quantity/type validation, eligibility/dependencies, quote arithmetic, persistence and stale-version conflicts, consent/token access, review transitions, expiry and deletion.
2. Run notebook 05 in a Windows Python kernel to exercise **real OCR**, not the mocked OCR in unit tests. Read unresolved cases; do not interpret a nonmatch as fraud automatically.
3. Start the app, keep default office inputs and confirm Rs 2,619. Add P09 at site-1 and confirm Rs 3,118 plus Rs 1,500 setup. Remove the qualifying fibre while P09 remains and confirm rejection.
4. Save quote, accept notice, upload K02 address proof and signatory ID, and submit. Confirm review-required state, then use clearly labelled demo operator controls with a note. Check scheduling dates and persistence after refresh.
5. Repeat with K11 address proof to confirm stale-proof approval is blocked. Test an inactive GST against a GST-required product via `/docs` or notebook.
6. Withdraw consent and confirm the journey and linked quote are no longer retrievable. The original dataset must remain untouched.

Verification so far: 37 automated tests passed after the OCR-correction changes; notebooks 03/04 were executed in native Jupyter; browser checks exercised the quote, consent, real address/signatory OCR, review and simulated activation. Final verification results are appended below. The test stack currently emits a Starlette/httpx deprecation warning; no failed assertions resulted.

## 12. Known limitations and future work

**Submission handoff:** final artifacts are in `submission/`; see `submission/READY_CHECKLIST.md`. Add your team details and upload through the required submission channel. Broader language/accessibility testing and full Hindi localization remain future improvements.

**Next product iterations:** contextual recommendation using existing contracts/tools, better OCR layout handling and explicit correction review, broader document/identity rules, staff review dashboard, asynchronous OCR/jobs, richer serviceability/site modelling and notifications.

**Before any real customer pilot:** authentication and role-based access; secure token/session design; encryption/key management; authorized registry integrations; actual serviceability/payment/e-sign/provisioning; approved privacy/retention policy; background cleanup and crash recovery; audit/security testing and monitoring. Local SQLite deletion is not secure erasure and does not remove copies/backups. Retention applies to uploaded evidence, not the supplied research dataset or notebook artifacts.

**Stretch only after the core journey:** voice/WhatsApp, additional languages and propensity scoring with chronological validation and no outcome leakage. No propensity model is currently implemented.

Pilot hypotheses: conversion 7.36% -> 10%; CAC <=Rs 12,000; mean activation <=12 days with product-mix adjustment; chase calls <=1; six-month churn <=12% after cohorts mature. None of these improvements has been measured in a real pilot.


## 13. Final verification record

- **37 automated tests passed** including explicit identifier confirmation and rejection of cancelled GST after correction.
- **All six notebooks have executed successfully in native Jupyter**, with outputs saved. Notebooks 01/02 now include natively rendered charts.
- **Real OCR:** processed all 12 GST certificates. Direct identifier resolution was **0/12** because of OCR character/layout errors; the blurred K04 certificate produced only 28 characters. This is a measured limitation, not a successful automatic-KYC rate.
- **Explicit correction:** notebook 06 verifies the K02 user-confirmed registration against the registry, retains original OCR concerns and masks the response. There is no silent character substitution. The UI has “Correct an unreadable registration number” after upload.
- **Local AI:** Ollama 0.40.15 and qwen2.5:1.5b installed on this machine. English and Hindi examples correctly returned five employees, one site, five email users, five devices and Rs 4,000 budget. An incomplete clinic description left unspecified counts null. Initial failures were corrected by tightening required schema fields and the extraction prompt. This small acceptance sample is not a general accuracy benchmark.
- **Browser:** verified office quote, saved quote, consent, actual K02 address/signatory OCR, review and simulated activation. Verified resume and the 390-pixel mobile quote/tracker layout. The final browser AI check also succeeded: local-model extraction populated the office profile before the Rs 2,619 quote and consent screen.
- **Privacy:** application tests verify token checks, deletion and expiry. These are prototype controls, not a production security certification.

The launcher now defaults to qwen2.5:1.5b. You may override UDYAM_OLLAMA_MODEL or set it to an empty string for guided-form mode. Installation is complete; the `ollama` integrations menu is unrelated to running this app. Press Esc to leave it. Use `ollama list` to inspect installed models.

Screenshots: `docs/screenshots/tracker-preview.png` and `docs/screenshots/mobile-quote-preview.png`. They show a synthetic completed journey, not real activation.


## 14. Completed submission materials

- `submission/Udyam_Digital_Business_Case.pptx`: ten editable slides using the supplied template artwork; all slides rendered and visually checked; structural/layout validation passed.
- `submission/Privacy_and_Security.pdf`: one-page privacy note.
- `submission/Solution_Architecture.pdf`: one-page architecture diagram.
- `submission/Udyam_Digital_Demo.mp4`: approximately 2 minutes 42 seconds, 1280x720 H.264 with locally synthesized narration. It pans through actual captured app screens and slides; it is not a continuous live screen recording. Captions and transcript are included.
- `submission/Udyam_Digital_Source.zip`: source, six executed notebooks, documentation and supplied synthetic inputs. Excludes dependencies, runtime databases, temporary files and caches.
- `submission/Udyam_Digital_Submission.zip`: the above deliverables together with the checklist and checksums.

The preview server is stopped after verification. Start it using `python -m backend.run`. The installed Ollama model remains available. Nothing has been uploaded or published externally.


## 15. Clean folder guide and code submission

| Folder | Purpose |
|---|---|
| `backend/` | Python API, catalogue rules, local AI, OCR and journey logic |
| `frontend/` | Browser interface |
| `tests/` | Automated behaviour checks |
| `analysis/` | Six executed notebooks and supporting CSV/JSON results; original data is separate |
| `YTL_TrackA_Udyam_Digital_Data/` | Original synthetic inputs, kept under their supplied name to preserve notebook/runtime paths |
| `brief/` | Original problem statement and presentation template |
| `docs/` | Architecture, privacy/security review, business case and recording script |
| `docs/screenshots/` | Captured demo and mobile verification images |
| `docs/planning/` | Historical plans/findings; current status is in this README |
| `tools/` | Reproducible submission packager and legacy analysis exporter |
| `submission/` | Final slide deck, PDFs, video and clean code/submission ZIPs |
| `.dependencies/` | Local installed libraries; excluded from source submission |
| `runtime/` | Local demo database, retained to preserve current progress; excluded from submission |

Cleanup removed macOS extraction metadata, Python/test caches, temporary build renders/scripts, narration intermediates and disposable verification databases. The current demo database and all original synthetic inputs were preserved. Nothing was published externally.

For the code repository, extract `submission/Udyam_Digital_Source.zip` into a clean repository and commit those contents. Do not upload the entire local working directory. The organizer asks for a code repository; the ZIP prepares its contents but is not a published repository URL. Install dependencies using the documented requirements. Rebuild both archives using `python tools/package_submission.py` after changes.

See `docs/SECURITY_REVIEW.md` for requirement-to-control mapping, evidence and gaps. Do not claim production DPDP compliance, encryption, full authentication or live government validation.
