# Steps 1 and 2: working brief

## Decision
Prioritise professional offices for the first self-service journey. They produce 138 activations from 1,247 leads (11.07%), with the lowest observed segment CAC (Rs 10,694.71) and mean activated monthly revenue of Rs 6,795.87. Small multi-site businesses are the second commercial pilot: 83/755 activate, with mean monthly revenue Rs 31,233.49, but require per-site coordination. Include a no-GST micro-business demo to prove accessibility. Micro businesses are the largest group but have 4.06% conversion, Rs 20,007.09 CAC and 22.73% observed churn; do not justify prioritisation by volume alone.

## Customer and workflow
First persona is a hypothetical five-person, single-site professional office in a tier-2 city seeking reliable connectivity, five email accounts and device protection. This is a design persona, not a claimed dataset row.

1. Welcome: choose English or Hindi; explain purpose and offer assisted help. Preserve language through checkout and errors.
2. Discovery: collect business type, city/tier, employee and site count, current connection, budget and required capabilities. Ask users for email seats/devices rather than assuming every employee needs every licence. Do not request KYC documents yet.
3. Recommendation: server filters catalogue eligibility and dependencies. Assistant explains the best fit and a cheaper alternative in plain language. Missing serviceability data produces a pending-serviceability label, not a promise.
4. Quote: show quantities, recurring charges, setup, product contract lengths and installation estimates. Revalidate every add-on change. Save a versioned quote and allow return without restarting.
5. KYC consent: explain purpose, documents needed, mock registry use and proposed retention. Require affirmative consent before upload. Permit cancellation and deletion requests.
6. KYC: extract documents, show extracted values for correction, compare registration and identity/address information with mock records. Require active GSTIN only for products that need it. Missing or uncertain evidence routes to review; do not invent a universal regulatory exemption for no-GST users.
7. Confirmation: record accepted quote and KYC state; generate a mock order. Clearly label simulated payment, provisioning and signature integrations.
8. Tracking: submitted -> KYC verified/review required -> serviceability confirmed -> scheduled -> provisioned -> activated. Show product-level progress, blockers, next action and last update. Activation is not instantaneous merely because signup is digital.
9. Assisted handoff: preserve consented context, preferred language and quote for an assigned partner. Record referral/partner attribution so field channels participate. Back-office UI remains a stretch goal.

## Catalogue-backed demo offers
Prototype pricing assumption: use catalogue minimum rates, without discounts; prices are illustrative and tax treatment is unspecified by source. Confirm taxes before a real checkout. Setup amounts assumed per purchased unit. Do not claim prices are market validated.

- Office starter: P02 x1 (1499), P16 x5 (625), P20 x5 (495) = Rs 2,619/month; setup zero; all 12-month minimum contracts. Both tiers allowed, no GST requirement. Estimated longest catalogue installation 5 days, subject to serviceability and scheduling.
- Optional resilience: P09 x1 adds Rs 499/month plus Rs 1,500 setup; prerequisite P02 satisfied. Total Rs 3,118/month.
- Micro connectivity: P01 x1 = Rs 999/month, zero setup, 12 months; optional P19 x1 adds Rs 599/month and Rs 2,500 setup. Do not automatically add GST-required WhatsApp API P15 for unregistered businesses.
- Three-site example: P02 x3 + P09 x3 = Rs 5,994/month and Rs 4,500 setup; 12-month products. SD-WAN P10 remains optional and requires 10 employees, three sites, active GSTIN and a qualifying connection; it also introduces a 24-month commitment.

## Findings and implications
Overall conversion is 7.36%; blended CAC is Rs 15,053.37 (all lead acquisition spending / activated customers). Average activation is 17.62 days; follow-up calls average 3.01 among activated customers. Observed churn is 56/368 = 15.22%. Mean monthly activated value is Rs 12,350.52; this must not be confused with the brief's median of roughly Rs 6,900.

The funnel is 5000 -> 3406 -> 1974 -> 861 -> 588 -> 368. Needs-assessed to quote-accepted loses 1113 leads, a 56.38% drop, the worst proportional transition. Lead-to-contact loses 1594, the largest absolute loss. Thus instant discovery and transparent quoting address different friction points. These are design hypotheses, not causal estimates.

Recorded drop reasons include 805 unreachable leads, 531 owners without time for a visit, 414 price objections, 325 current-provider lock-ins, and 296 unscheduled sales visits. Enable asynchronous progress, cheaper eligible alternatives, and deferred follow-up for contract lock-in. Counts reflect recorded reasons and do not prove an intervention would recover every lead.

GSTIN holders convert at 9.56% versus 2.05% without GSTIN. This association can reflect segment and other differences; it does not establish that acquiring GST registration causes better conversion.

## Data work and limitations
Run `python tools/analyze.py` from the project root. It uses Python standard library only and leaves supplied files untouched. Outputs include funnel, segment, channel, registration, city-tier and language summaries, segment/stage drop reasons and JSON quality checks. No raw contact or identifier values are exported.

All four CSV primary keys are unique; nonempty lead GSTIN and Udyam values match their registries. Blank activation outcomes belong to nonactivated leads and must not be filled with zero revenue/churn ratings. Registry existence is not equivalent to active GST status. Current quality checks cover counts, keys, blankness and joins; full date chronology, document OCR, identifier checksum and purchased-bundle validation remain implementation work.

The pack is synthetic and has six-month outcomes despite an Apr-Jun cohort and a mandated July 15, 2026 KYC reference date. Use these as supplied retrospective exercise labels, not evidence that six months have elapsed at the demo reference date. Do not use churn, final stage, purchase value or future dates as inputs to a lead propensity model. Average 0-10 survey rating is not the standard NPS calculation.

## Acceptance criteria before application implementation
- Agree initial office journey, second commercial segment and no-GST exception demo.
- Demonstrate quoted arithmetic and product dependency checks for the examples above.
- Specify resumed sessions, insufficient budget, inactive GSTIN, missing document, OCR uncertainty and unavailable serviceability paths.
- Separate instant quote/onboarding completion from physical installation timelines.
- Keep baseline measures separate from proposed pilot goals: 10% conversion, CAC <= Rs 12,000 and <=1 follow-up call are hypotheses to evaluate on comparable cohorts, not prototype results.
- Deliver later: working repository, <=3-minute video, architecture diagram, <=10-slide business case and one-page privacy/security note, as required by the case.
