# Execution plan: Udyam Digital

## Scope and current position
The brief requires a GenAI advisor, transparent editable quote, Smart KYC with extraction and mock lookups, and an order tracker. Submission: repository, maximum three-minute video, architecture diagram, at most ten business-case slides and a one-page privacy/security note. Voice, WhatsApp, partner dashboard and propensity scoring are stretch work.

Completed: initial EDA and workflow documentation; two notebooks; prototype bundle-level eligibility/pricing logic with 14 behaviour checks. Not completed: deployed backend, persistent orders, actual advisor integration, OCR, KYC decisions, tracker and customer UI. Notebook code was executed sequentially in Python; native Jupyter execution and inline chart rendering remain to verify.

## Verified EDA and interpretation
User-provided segment medians and churn rates match the CSV. Channel activation rates also match: referral 14.77%, website 4.32%, WhatsApp 2.79%. All 3,534 nonempty lead GSTINs join to the registry: 3,266 Active, 167 Cancelled, 101 Suspended. Registry presence is not eligibility.

One-call activated customers: n=34, mean survey rating 7.47, churn 5.88%. Five-call customers: n=43, mean rating 5.98, churn 27.91%. These are associations, not causal effects; intermediate churn is not strictly monotonic. Mean 0-10 rating is not standard NPS. Historical acquisition spending is not sufficient to forecast digital acquisition cost without a cost model.

Prioritise professional offices for initial self-service rollout; multi-site businesses for an assisted second pilot; low-cost micro bundles as an inclusion path. Manufacturers remain supported by catalogue rules and assisted handoff. Do not prioritise by revenue alone: margins, support costs and lifetime value are unavailable.

## Milestone 1 — Finish the evidence and test fixtures
Deliverables: extend 01_EDA.ipynb with registry status, channel economics, calls/outcome analysis and within-segment comparisons; add 03_KYC_Audit.ipynb and a redacted fixture manifest.

Inspect all 47 images for all 12 applicants. For each document record type, readability, extracted field candidates and visible evidence. Compare applicant documents to each other and registries. Label findings observed, uncertain or missing; do not assume the supplied examples are the answer key. No judge-only materials are required or sought. Missing documents must remain visible rather than silently excluded.

KYC reference date is 2026-07-15. Flag address proofs older than 90 days; test exactly 90 days, 91 days and future dates. Low-confidence OCR routes to correction/review. Registry has no authorised-signatory name: verify only against explicit supporting document evidence, otherwise mark unverified. Do not invent a registry comparison.

Exit: independently reviewable EDA, 12 applicant records and evidence-backed expected review outcomes. No unverified clean applicant is designated the happy path.

## Milestone 2 — Reliable foundations
Use FastAPI and SQLite for the local prototype, with notebooks retained for analysis and interactive debugging. Runtime APIs require importable application modules; notebooks remain the analysis source of truth, not the server runtime. Select dependency versions when implementation starts and document installation.

Import catalogue and registries without changing source CSVs. Add typed profiles, site-level selections, quantities and versioned quotes. Normalize city tiers and units. Validate every quote server-side: tier, minimum employees/sites, active GST when required, positive integral quantities and dependencies. For multiple sites, enforce relevant connectivity dependencies at the selected site. Keep product contract terms separate; do not silently assign all products the shortest contract.

Price policy: catalogue minimum for prototype; no inferred discounts. Setup per purchased unit is an explicit assumption. Taxes are unspecified and must be labelled. Estimate installation from catalogue times, pending serviceability, with no guaranteed date claim.

Lookup APIs: GET /gstin/{id}, GET /udyam/{id}; malformed inputs, not found and inactive status must be distinct. Validate GSTIN format/checksum, accepting the synthetic PAN X exception; validate Udyam using the synthetic district 00 exception. Valid structure never substitutes for registry status. Validate checksum implementation against supplied identifiers plus deliberately mutated examples. Disable or redact access logs containing lookup identifiers; do not expose unrestricted public registry search.

Additional APIs: POST /recommendations, POST /quotes, PATCH /quotes/{id}. Return itemised totals and specific rule failures. GST verification state is server-derived, never a client-provided boolean.

Exit: tested office and no-GST quotes; invalid GST, missing dependency, tier/size failures, quantity errors and multi-site allocation cases; reproducible startup and database persistence.

## Milestone 3 — First complete customer journey
Build mobile screens for discovery, recommendation and quote. Ask language, business type, city, size/sites, current setup, required capabilities and budget. Ask quantities explicitly. An LLM extracts a structured profile and explains a rules-validated recommendation; it cannot invent products or prices. Clarify missing answers and allow users to edit the extracted profile. Include an explicit deterministic fallback for API outages; label that fallback honestly. Model/provider setup is an implementation dependency, not a completed capability.

Show cheaper eligible alternatives if the requested capabilities exceed budget. Persist a draft and resume state. English and Hindi first; additional languages only after end-to-end validation. Use the supplied minimum-price office example (Rs 2,619/month) as a test fixture, not evidence of real savings against the historical median (the services differ).

Exit: a user can answer questions, receive a valid explained bundle, edit quantities/add-ons and save a consistent quote. No KYC documents are needed for discovery.

## Milestone 4 — Consent, Smart KYC and tracker
Record consent version, purpose and time before upload. Extract fields with OCR and present corrections. Cross-check legal/trade names, addresses and identifiers with explainable matching; avoid treating punctuation differences as fraud. Separate rule failures, incomplete evidence and ambiguous OCR. Retain manual-review reasons and remediation steps.

Keep documents outside public assets, exclude them from model requests unless necessary and consented, mask UI identifiers and suppress sensitive logs. Proposed demo policy: delete raw uploads after decision or 30 days, whichever occurs first; implement expiry/deletion and distinguish this prototype policy from production retention obligations. Review applicable requirements before making compliance claims.

Create orders from accepted quote snapshots. Track product-level progress: submitted, review, verified, serviceability pending, scheduled, provisioned, activated. Gate transitions, record timestamps, expose blockers and next actions. Simulated provisioning must be visibly labelled. Route failed/uncertain KYC and complex accounts to a partner with only necessary consented context. Record partner attribution.

Exit: verified happy path plus missing document, inactive GST, uncertain OCR and unavailable serviceability scenarios; refresh/resume works; estimated dates are distinguishable from confirmed dates.

## Milestone 5 — Business case and submission
Write architecture and draft demo script during foundations; update them to match the finished system. Finalise privacy note after actual controls are implemented. Three-minute demo: 20s problem, 60s advisor/quote, 55s KYC and correction, 25s tracker/handoff, 20s evidence and impact hypotheses.

Proposed pilot targets, not achieved results: overall conversion 7.36% -> 10%; blended CAC Rs 15,053 -> <=Rs 12,000; mean activation 17.62 -> <=12 days (product-mix adjusted); follow-up calls 3.01 -> <=1; six-month churn 15.22% -> <=12%. Churn requires a matured cohort and cannot be demonstrated in a short pilot. Compare comparable segments/channels and count all acquisition costs. Separate signup time from physical installation time.

Exit: tests pass, setup instructions reproduce the app, notebooks open and run, all four mandatory modules are demonstrated, repository contains no secrets, deliverables stay within limits.

## Deferred work
Voice, WhatsApp integrations, a richer partner dashboard and propensity scoring follow the mandatory journey. If scoring is attempted: use only features available at prediction time, chronological train/test separation, a baseline, calibration and lift-at-contact-capacity. Exclude final stage, drop reason, purchase value, activation dates, churn and survey outcomes. Do not represent high propensity as causal benefit from a sales call.

## Immediate execution order
1. Finish notebook verification and evidence-based audit of all 12 KYC applicants.
2. Harden catalogue logic and build mock lookup APIs with checksum tests.
3. Deliver discovery -> recommendation -> editable persisted quote as the first working app increment.
4. Add consent/OCR/review, then order tracking and partner handoff.
5. Complete business case and demo; only then evaluate stretch goals.
