# Review-driven revision

## Implemented
- Separate operator credential required for approval, scheduling and activation. Customer-only calls return 403; assistance remains available.
- Business-type and site-count inference, four playbooks, service-specific reasons, follow-up questions, existing-POS preservation and migration prompts. Confirmed needs can select all 25 catalogue products across tested scenarios. Quantities are not silently inferred from employee counts.
- Tesseract/OpenCV adapter with deskew and pale/red watermark suppression on a derived copy. Image bytes use stdin/stdout, avoiding temporary original files. Windows OCR remains an explicit optional fallback.
- Signatory name, business and expiry extraction. Four-document consistency fast path, with explicit synthetic-documentary semantics. Corrections and exceptions remain review cases.
- Full catalogue price range, starting-price policy and separate illustrative 18% tax amounts. Actual tariff-selection criteria and tax classifications are not supplied, so a firm final invoice is not invented.
- Revised ten-slide deck: segment bundles, value comparison, revenue/contribution payback distinction, partner roles, journey diagram and risks.
- Revised one-page privacy note: DPDP Act/Rules, notice, roles, rights, grievance and breach-response design, clearly separated from implemented functionality.

## Measured evidence
48 automated tests passed on Windows. Notebook 07 executed against all 47 actual images, then replayed extracted text through the real API. GST direct resolution: 3/12. K02 and K12 passed documentary checks; ten cases stayed in review. K11 had stale-proof evidence. K01/K06/K09/K10 remain review cases, but not every planted fault is specifically classified because unresolved identifiers can prevent later comparisons. This is not a general document-authenticity benchmark.

Browser checks verified kirana and six-outlet recommendations. K02 was also verified in the live browser after uploading all four actual images, with automatic documentary clearance and no operator action. A focused GST-line OCR experiment did not improve the 3/12 result and was not retained. Current evidence and source checks are recorded below. Tesseract was also verified on Ubuntu: all 47 images processed, 4/12 GST identifiers resolved, K02/K03/K12 cleared and nine cases remained in review. Engine versions differ; Linux outputs have separate filenames.

## Remaining / not claimed
- No full multi-turn chat memory: the advisor asks follow-ups and the user answers via editable needs fields.
- Larger local models are configurable, not automatically downloaded or benchmarked.
- No production identity/authority verification, authenticated operator accounts, encrypted SQLite or real telecom provisioning.
- Updated narrated demo produced from actual captured screens and verified results. It is an edited walkthrough, not a continuous live recording. The previous video remains historical.
- Team/contact details and repository destination were requested but not supplied. No repository URL is invented or publication claimed.
- Earlier ZIP containing propensity/back-office code is not present in the supplied workspace. No port claimed.

## Recording plan (under three minutes)
0:00–0:40: kirana, zero email/device seats; show POS/UPI and deferred WhatsApp eligibility.
0:40–1:10: six-outlet restaurant; show failover/CCTV per location and provisional quantities.
1:10–2:10: prefill an office quote, consent, upload all four K02 images, then Check documents. Show automated synthetic documentary pass.
2:10–2:40: separate prepared K11 journey with its own documents; show stale-proof review/block, not mixed-applicant evidence.
2:40–3:00: explain operator separation, remaining OCR limitations and simulated activation.
Rehearse first. Do not describe the original captured-screen montage as a new live recording.

## Final verification

- Windows: 48 tests passed.
- Notebook 07: executed and saved.
- Browser: kirana POS/UPI, six-outlet failover/CCTV, and actual four-image K02 automatic clearance verified.
- Deck: 10 slides, all rendered and reviewed, native-table and package/layout checks passed.
- PDFs: one page each, rendered and visually reviewed.
- Ubuntu: 47 tests passed and the full real OCR/API audit completed. The later tax-inclusive-budget regression passed on Windows. Linux evidence files are included.
