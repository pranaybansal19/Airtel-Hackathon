# Revised ten-slide business case

The current deck is submission/Udyam_Digital_Business_Case.pptx.

1. Solution
2. Baseline and pilot hypotheses
3. Four segment bundles
4. Journey diagram
5. Value at similar starting spend
6. Revenue recovery and margin sensitivity
7. Document checks and exceptions
8. Competitive landscape: JioBusiness, Airtel Business, local providers and proposed Udyam journey
9. Risks and mitigations
10. Rollout, partner responsibilities and release gates

All prices are starting catalogue estimates; tax is illustrative. Existing spend is a different service mix. CAC divided by revenue is not profit payback. Proposed partner assignments are not live integrations.

Competitive sources (accessed 7 November 2026): https://www.jio.com/jcms/business/enterprise-bundle-plans/ and https://www.airtel.in/b2b/contact-us/. The comparison does not establish relative prices, onboarding times or superiority.
