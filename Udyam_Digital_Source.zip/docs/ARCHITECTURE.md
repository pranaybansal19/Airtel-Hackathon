# Architecture and data flow

```mermaid
flowchart LR
    User[Business owner / browser] --> UI[HTML CSS JavaScript\nDiscover · Quote · KYC · Tracker]
    UI --> API[FastAPI localhost API]
    API --> Rules[Deterministic catalogue rules]
    Rules --> Catalogue[25-product CSV]
    API --> Registry[Synthetic GST / Udyam CSV indexes]
    API --> DB[(SQLite quotes and journeys)]
    API --> OCR[Memory image → Tesseract / OpenCV → evidence]
    OCR --> Decision[Documentary consistency decision]
    API --> AI[Optional local Ollama\nstructured business facts only]
    Decision --> Review[Exceptions to operator review]
    Review --> Tracker[Simulated scheduling / activation]
```

## Trust boundaries
- Browser-provided counts, items and quantities are schema-validated; GST eligibility is computed server-side.
- Model output is untrusted structured data. Users confirm extracted fields. Prices and eligibility never come from the model.
- Quotes have immutable versions. Acceptance requires the latest version and snapshots the result into a journey.
- Consent precedes extraction. Journey endpoints require its bearer token; quote/registry routes remain local prototype routes without account-level authorization.
- Uploaded images are validated, re-encoded into a temporary PNG, processed locally, then removed. Intermediate normalized text is private evidence and expires under the documented policy.
- The registry proves only what its supplied fields contain. It has no signatory-authority or coverage data.
- Synthetic documentary clearance, operator review, serviceability, scheduling and activation are never represented as live operator integrations.

## Future production components
Authentication/roles; encrypted durable object storage; background cleanup and job queue; monitoring; real serviceability/registry integrations; reviewed consent/retention policy; payment/e-sign; provisioning adapters; staff review UI; notifications and retry policies.

Privileged demo actions require X-Operator-Token in addition to the journey token. Customer-only calls return 403. Tesseract is default; Windows OCR is optional. See REVISION_REVIEW.md for measured accuracy and limitations.
