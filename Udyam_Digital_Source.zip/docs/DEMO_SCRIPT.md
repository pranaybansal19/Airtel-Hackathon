# Updated demo

The current video is submission/Udyam_Digital_Demo.mp4. Full narration is in submission/Demo_Transcript.txt, with captions in Demo_Captions.srt. It shows actual captured screens, including the revised advisor, price/tax range, K02 pass and K11 stale-proof result. This is an edited narrated walkthrough, not a continuous live recording. See REVISION_REVIEW.md for the separate live-rehearsal plan.
