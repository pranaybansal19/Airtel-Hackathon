"""Build clean code and deliverable archives from an explicit allowlist."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'submission'
OUT.mkdir(exist_ok=True)
FOLDERS = ['backend', 'frontend', 'tests', 'analysis', 'docs', 'brief', 'tools', 'YTL_TrackA_Udyam_Digital_Data']
EXCLUDE = {'__pycache__', '.ipynb_checkpoints', '.pytest_cache', '__MACOSX', '.git'}
files = [ROOT / name for name in ['README.md', 'requirements.txt', 'requirements-dev.txt', 'start.ps1', '.gitignore']]
for folder in FOLDERS:
    files += [p for p in (ROOT / folder).rglob('*') if p.is_file() and not EXCLUDE.intersection(p.parts) and p.suffix not in {'.pyc', '.db', '.sqlite', '.sqlite3'} and not p.name.startswith('.env')]
with zipfile.ZipFile(OUT / 'Udyam_Digital_Source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(ROOT))
artifact_names = ['Udyam_Digital_Source.zip','Udyam_Digital_Business_Case_7_Slides.pptx','Udyam_Digital_Business_Case_7_Slides.pdf','Privacy_and_Security.pdf','Solution_Architecture.pdf','READY_CHECKLIST.md','SUBMISSION_GUIDE.md','Udyam_Digital_Demo.mp4','Demo_Captions.srt','Demo_Transcript.txt']
artifacts = [OUT / name for name in artifact_names]
missing = [p.name for p in artifacts if not p.exists()]
if missing:
    print('Clean source archive created. Full bundle requires: '+', '.join(missing))
    raise SystemExit(0)
(OUT / 'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in artifacts), encoding='utf-8')
with zipfile.ZipFile(OUT / 'Udyam_Digital_Submission.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in artifacts + [OUT / 'SHA256SUMS.txt']:
        archive.write(path, path.name)
for name in ['Udyam_Digital_Source.zip', 'Udyam_Digital_Submission.zip']:
    with zipfile.ZipFile(OUT / name) as archive:
        assert archive.testzip() is None
        assert not any(EXCLUDE.intersection(Path(p).parts) for p in archive.namelist())
        print(name, len(archive.namelist()), 'entries: integrity checked')
