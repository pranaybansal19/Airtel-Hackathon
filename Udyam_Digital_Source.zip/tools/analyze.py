import csv, pathlib, collections, statistics, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'YTL_TrackA_Udyam_Digital_Data'
OUT=ROOT/'analysis'
def read(name):
    with (DATA/name).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def write(name,rows):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
r=read('smb_leads.csv'); active=[x for x in r if x['outcome']=='Activated']
def mean(rows,k): return round(statistics.mean(float(x[k]) for x in rows if x[k]),2) if any(x[k] for x in rows) else None
def stats(rows):
    a=[x for x in rows if x['outcome']=='Activated']; cost=sum(float(x['acquisition_cost_inr'] or 0) for x in rows)
    return dict(leads=len(rows),activations=len(a),conversion_pct=round(100*len(a)/len(rows),2),total_acquisition_cost=round(cost,2),blended_cac=round(cost/len(a),2) if a else None,avg_monthly_value=mean(a,'monthly_bundle_value_inr'),avg_activation_days=mean(a,'days_lead_to_activation'),avg_followup_calls=mean(a,'customer_follow_up_calls'),churn_values=dict(collections.Counter(x['churned_within_6_months'] for x in a)),avg_nps_rating=mean(a,'nps_score'))
summary={'overall':stats(r)}
for key in ['segment','lead_source','has_gstin','city_tier','preferred_language']:
    rows=[dict(group=v,**stats([x for x in r if x[key]==v])) for v in sorted(set(x[key] for x in r))]
    write(key+'_summary.csv',rows);summary[key]=rows
stages=['Lead','Contacted','Needs assessed','Quote accepted','KYC complete','Activated']; funnel=[]
for i,s in enumerate(stages):
    n=sum(stages.index(x['stage_reached'])>=i for x in r); prev=funnel[-1]['reached'] if funnel else n
    funnel.append(dict(stage=s,reached=n,conversion_from_previous_pct=round(n/prev*100,2),lost_since_previous=prev-n))
write('funnel.csv',funnel)
drops=[dict(segment=s,stage=st,reason=reason,count=n) for (s,st,reason),n in collections.Counter((x['segment'],x['stage_reached'],x['drop_reason']) for x in r if x['drop_reason']).most_common()];write('drop_reasons.csv',drops)
quality={}
for name,idcol in [('smb_leads.csv','lead_id'),('product_catalogue.csv','product_id'),('mock_gstin_registry.csv','gstin'),('mock_udyam_registry.csv','udyam_number')]:
    rows=read(name);quality[name]={'rows':len(rows),'duplicate_keys':len(rows)-len(set(x[idcol] for x in rows)),'blank_counts':{k:sum(not x[k] for x in rows) for k in rows[0]}}
for field,file in [('gstin','mock_gstin_registry.csv'),('udyam_number','mock_udyam_registry.csv')]:
    ids={x[field] for x in read(file)};quality[field+'_unmatched_nonempty']=sum(bool(x[field]) and x[field] not in ids for x in r)
summary['quality']=quality;summary['funnel']=funnel
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'overall':summary['overall'],'segments':summary['segment'],'gstin':summary['has_gstin'],'quality':quality},indent=2))
