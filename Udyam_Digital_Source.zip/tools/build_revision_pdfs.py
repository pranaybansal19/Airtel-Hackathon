from pathlib import Path
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4,landscape
from xml.sax.saxutils import escape
pdfmetrics.registerFont(TTFont('Arial','C:/Windows/Fonts/arial.ttf'));pdfmetrics.registerFont(TTFont('ArialBold','C:/Windows/Fonts/arialbd.ttf'))
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyCustom',fontName='Arial',fontSize=10.5,leading=14,spaceAfter=6));styles.add(ParagraphStyle(name='HeadingCustom',fontName='ArialBold',fontSize=11,leading=14,textColor=colors.HexColor('#b20b18'),spaceBefore=7,spaceAfter=3));styles.add(ParagraphStyle(name='TitleCustom',fontName='ArialBold',fontSize=20,leading=24,spaceAfter=10))
story=[]
for block in Path('docs/PRIVACY_NOTE.md').read_text(encoding='utf-8').split('\n\n'):
 if block.startswith('Sources:'):
  block='Sources: DPDP Act, 2023 (MeitY); DPDP Rules, 2025 (MeitY Gazette, phased commencement). Source links are provided in docs/PRIVACY_NOTE.md.'
 if block.startswith('#'):
  heading,_,body=block.partition('\n')
  style='TitleCustom' if heading.startswith('# ') else 'HeadingCustom'
  story.append(Paragraph(escape(heading.lstrip('# ')),styles[style]))
  if body: story.append(Paragraph(escape(body),styles['BodyCustom']))
 else: story.append(Paragraph(escape(block),styles['BodyCustom']))
SimpleDocTemplate('submission/Privacy_and_Security_Revised.pdf',pagesize=A4,rightMargin=36,leftMargin=36,topMargin=30,bottomMargin=30).build(story)
p='submission/Solution_Architecture_Revised.pdf';c=canvas.Canvas(p,pagesize=landscape(A4));c.setFont('ArialBold',23);c.drawString(35,550,'Udyam Digital: components and trust boundaries')
boxes=[(40,410,200,75,'Customer browser','Needs, quote, consent, tracker'),(315,410,200,75,'FastAPI + validation','Token checks and workflow'),(600,410,200,75,'Rules + catalogue CSV','Eligibility, prices and range'),(40,265,200,75,'Local Ollama','Business facts, user confirmed'),(315,265,200,75,'Tesseract + OpenCV','Deskew, derived image, OCR'),(600,265,200,75,'Synthetic registries','GST / Udyam comparisons'),(40,120,200,75,'SQLite','Versioned quotes and journeys'),(315,120,200,75,'Document decision','Clean demo pass / exceptions'),(600,120,200,75,'Operator credential','Required for privileged actions')]
for x,y,w,h,title,body in boxes:
 c.setStrokeColor(colors.HexColor('#b20b18'));c.roundRect(x,y,w,h,5);c.setFillColor(colors.black);c.setFont('ArialBold',13);c.drawString(x+10,y+h-24,title);c.setFont('Arial',9);c.drawString(x+10,y+20,body)
for x1,y1,x2,y2 in [(240,450,315,450),(515,450,600,450),(415,410,415,340),(340,410,340,375),(340,375,140,375),(140,375,140,340),(515,300,600,300),(415,265,415,195),(315,155,240,155),(515,155,600,155)]:c.line(x1,y1,x2,y2)
c.setFont('Arial',10);c.drawString(40,65,'KYC images never enter the AI adapter. Tesseract uses memory pipes. Evidence expires or is deleted on clearance/withdrawal.');c.drawString(40,46,'Localhost prototype: no live provisioning, no government identity verification, no production account/role system.');c.save()
import fitz
for name in ['Privacy_and_Security_Revised','Solution_Architecture_Revised']:
 d=fitz.open('submission/'+name+'.pdf');assert len(d)==1,(name,len(d));d[0].get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save('runtime/revision/'+name+'.png')
print('Both PDFs are one page and rendered')
