"""Real OCR audit and API replay; no identities or tokens in exported results."""
from pathlib import Path
import sys,json,csv
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'.dependencies'),str(ROOT)]
from PIL import Image
from fastapi.testclient import TestClient
from backend.tesseract_ocr import read_image
from backend.ocr import evidence
from backend.app import create_app
from backend.journey import NOTICE_VERSION
import backend.journey as journey

def run():
    rows=[];texts={}
    for p in sorted((ROOT/'YTL_TrackA_Udyam_Digital_Data/kyc_documents').glob('*.png')):
        kind='gst' if '_gst_' in p.name else 'udyam' if '_udyam_' in p.name else 'address' if '_address_' in p.name else 'signatory'
        with Image.open(p) as image: output=read_image(image)
        d=evidence(kind,output['text']);texts[p.name]=output
        rows.append({'file':p.name,'kind':kind,'registry_resolved':bool(d.get('_registry_key') or d.get('_udyam_key')),'checks':' | '.join(d['checks']),'deskew':output['preprocessing']['deskew_degrees']})
    with (ROOT/'analysis/tesseract_results.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    results=[];original=journey.extract
    try:
        with TestClient(create_app(ROOT/'runtime/revision-audit.sqlite3')) as client:
            for applicant in [f'K{i:02d}' for i in range(1,13)]:
                q=client.post('/quotes',json={'profile':{'employee_count':5,'sites':[{'site_id':'one','city_tier':2}]},'items':[{'product_id':'P02','site_id':'one','quantity':1}]}).json()
                j=client.post('/journeys',json={'quote_id':q['id'],'quote_version':1,'consent':True,'notice_version':NOTICE_VERSION}).json();headers={'X-Journey-Token':j['access_token']}
                for kind,suffix in [('gst','gst_certificate'),('udyam','udyam_certificate'),('address','address_proof'),('signatory','signatory_id')]:
                    name=applicant+'_'+suffix+'.png'
                    if name not in texts: continue
                    journey.extract=lambda _,n=name:texts[n]
                    response=client.post('/journeys/'+j['id']+'/documents',headers=headers,json={'kind':kind,'image_base64':'replay of real OCR above'})
                    assert response.status_code==200,response.text
                response=client.post('/journeys/'+j['id']+'/submit',headers=headers)
                assert response.status_code==200,response.text
                data=response.json()
                results.append({'applicant':applicant,'status':data['status'],'checks':data['review_checks']})
                client.delete('/journeys/'+j['id'],headers=headers)
    finally: journey.extract=original
    (ROOT/'analysis/tesseract_journey_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    assert next(r for r in results if r['applicant']=='K02')['status']=='verified_demo'
    for applicant in ['K01','K06','K09','K10','K11']:
        assert next(r for r in results if r['applicant']==applicant)['status']=='review_required'
    return {'gst_resolved':sum(r['registry_resolved'] for r in rows if r['kind']=='gst'),'gst_total':12,'documents':len(rows),'journeys':results,'method':'Real Tesseract extraction, then API replay of extracted text; no ground-truth identifier injection'}

if __name__=='__main__':
    result=run();print(json.dumps(result,indent=2))
