# Udyam Digital

Local hackathon prototype for business discovery, catalogue-backed quoting, document checks and tracking. All supplied data is synthetic. This is the current guide; docs/planning contains historical records.

## Status after review

The advisor now infers segments from business type and locations, uses four playbooks, asks follow-up questions and explains selected and deferred services. Confirmed needs can select all 25 catalogue products across tested scenarios. It is a guided advisor, not a full multi-turn chatbot. AI extracts facts; deterministic rules select and price services.

Tesseract replaces Windows OCR as the default. All 47 images were processed. Direct GST identifier resolution improved from 0/12 to 3/12 on Windows and 4/12 on Ubuntu. K02/K12 passed on Windows; K02/K03/K12 passed on Ubuntu. Remaining cases stayed in review. A documentary pass is not government identity or signing-authority verification. Read analysis/07_Revision_Verification.ipynb and docs/REVISION_REVIEW.md.

Customer tokens cannot approve, schedule or activate their own journeys. Those actions require a separate operator secret. This fixes the reported permission flaw but does not replace production user accounts and roles.

## Run on Windows

```powershell
python -m pip install --target .dependencies -r requirements.txt
# Install Tesseract + English data if absent (installed on this development machine):
winget install --id UB-Mannheim.TesseractOCR --exact
python -m backend.run
```

Open http://127.0.0.1:8000/ and http://127.0.0.1:8000/docs. If an older server is already running, stop it in its terminal and restart to load code changes. Static-file refresh alone does not reload Python code.

## Linux setup (Ubuntu acceptance verified)

```bash
sudo apt-get install tesseract-ocr tesseract-ocr-eng
python -m pip install --target .dependencies -r requirements.txt
python -m backend.run
```

Tesseract is a separate OS executable, not installed by pip. Set TESSERACT_CMD to its executable path if needed. The default adapter uses OpenCV deskew and red-channel watermark suppression through memory pipes. This preprocessing targets the supplied pale/red specimen marks; it is not universal watermark removal. UDYAM_OCR_ENGINE=windows selects the legacy Windows-only adapter.

## Local AI and stronger-model option

Ollama uses the fixed loopback endpoint http://127.0.0.1:11434/api/chat. The default qwen2.5:1.5b model is installed and was tested on a small English/Hindi sample. No cloud key is needed. For a stronger local option, with sufficient memory:

```powershell
ollama pull qwen2.5:7b
$env:UDYAM_OLLAMA_MODEL='qwen2.5:7b'
python -m backend.run
```

The 7B option has not been downloaded or benchmarked here. Missing/invalid model output falls back to the form. Users confirm extracted values. KYC images never enter this adapter. Full regional-language coverage is not claimed.

## Operator separation

Privileged demo controls are disabled unless UDYAM_OPERATOR_TOKEN is set in the server environment. Generate a long random secret locally; keep it out of source, logs and shared videos. Enter it only in the operator credential field when demonstrating privileged actions. The browser does not persist that field. Requests require X-Operator-Token as well as the journey token. Customer assistance requests do not need the operator secret. No default/shared operator password is shipped.

The separate secret is a prototype boundary, not an authenticated staff account, role system or production session design.

## How the modules work

1. Advisor: business category and site count infer a segment. Retail gets POS/UPI needs, multi-site gets failover/CCTV, manufacturing gets dedicated connectivity/firewall and a machine-count question. GST-dependent services are deferred when ineligible. Existing POS is retained unless replacement is confirmed. Users answer follow-ups through needs fields and regenerate the bundle.
2. Quote: server validates city tier, employees, sites, active GST, positive quantities and per-site dependencies. Prices start at catalogue minimum; the full min/max range is disclosed because the source has no tariff-selection criteria. Illustrative 18% tax and setup tax are separate modelling assumptions, not an approved tax determination. The office base remains Rs 2,619; illustrative total is Rs 3,090.42. Quotes are saved in SQLite with versions and accepted snapshots.
3. KYC: affirmative versioned consent precedes uploads. PNG/JPEG up to 6 MB and bounded dimensions are accepted. Tesseract extracts text from derived images. Checks cover identifiers, registry status, name/address consistency, address age and signatory name/business/expiry. Udyam whitespace around separators is normalised without substituting identifier characters. The reference date is 2026-07-15. Four consistent documents can pass synthetic checks automatically; corrections/uncertain cases require review. Live registry and signing-authority verification remain absent.
4. Tracker: SQLite stores events and state. Scheduling uses catalogue install-day estimates. Review approval/scheduling/activation are explicit demo actions guarded by a separate operator secret. Partner handoff records a queue and reason; it does not dispatch external work.

## Verification

48 automated tests passed on Windows. Ubuntu passed 47 tests plus the full 47-image OCR audit; the final tax-inclusive-budget regression was subsequently added and verified on Windows. Browser verification covered kirana, six-outlet recommendations and actual four-image K02 automatic documentary clearance.

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q --tb=short
python tools/verify_revision.py
```

Ubuntu 24.04 / Python 3.12 / Tesseract 5.3.4 was tested using the clean source archive. Windows uses Python 3.14 / Tesseract 5.4.0. Engine differences produced different recognition results. Linux evidence is saved as analysis/tesseract_results_linux.csv and analysis/tesseract_journey_results_linux.json.

The real-OCR audit takes longer than the unit tests. It writes masked/aggregate results to analysis/tesseract_results.csv and analysis/tesseract_journey_results.json. It replays actual extracted text through the API, not ground-truth IDs. Notebook 07 executes this audit. Earlier notebooks preserve historical experiments; notebooks 05/06 used the older demo-operator contract and require updates before rerunning those old cells. Their saved outputs are historical, not proof of the revised runtime.

Tests cover catalogue rules, quote versions, invalid input, consent, token access, expiry/deletion, customer rejection from operator actions, segment playbooks, existing-tool handling and product coverage. Unit-test OCR doubles are separate from real OCR auditing. No penetration test or unseen-scenario benchmark is claimed.

## Security and privacy

See docs/PRIVACY_NOTE.md and docs/SECURITY_REVIEW.md. Consent, purpose limitation, masked responses, local OCR, token hashes and deletion are implemented. Expiry cleanup is triggered on startup/access. Browser localStorage and SQLite are not application-encrypted. Quote/registry APIs lack account-level authorization. Before real users: authenticated roles, TLS, encryption/key management, scheduled cleanup, monitoring, legal review, working grievance/rights processes and breach handling.

## Folder guide

| Folder | Purpose |
|---|---|
| backend / frontend | Application code |
| tests | Repeatable checks |
| analysis | Seven notebooks, audit results and EDA |
| YTL_TrackA_Udyam_Digital_Data | Unmodified synthetic inputs |
| brief | Supplied case and presentation template |
| docs | Current architecture, privacy, review and recording guidance |
| docs/planning | Historical documentation |
| docs/screenshots | Verification screenshots |
| tools | Packager, verification audit and artifact source helpers |
| submission | Current deliverables and clean archives |
| runtime / .dependencies | Local state and libraries; excluded from code submission |

## Submission and remaining work

Use the clean source ZIP to populate a repository; submit its URL plus the requested deck, architecture, privacy note and live video. The packager excludes local databases, dependencies, caches and historical submission artifacts. Run python tools/package_submission.py after changes.

The revised deck includes risks, all segment bundles, partner roles, journey diagram and economics. Rs 10,695 professional-cohort CAC / Rs 2,619 monthly revenue is 4.08 months of revenue recovery, not profit payback. At assumed 50% contribution margin it is 8.17 months; actual delivery costs are not supplied. Rs 2,600 existing spend versus Rs 2,619 starter is a value comparison, not proven like-for-like savings.

The updated narrated demo is complete and included in submission/Udyam_Digital_Demo.mp4. It is an edited captured-screen walkthrough of actual app results, not a continuous live recording. Still required: team/contact details, repository destination/publication and wider OCR/model evaluation. The earlier video remains historical. No external upload has occurred. No propensity/back-office port is claimed because the earlier ZIP is not available.
