Set-Location -LiteralPath $PSScriptRoot
python -m backend.run
