import copy
from datetime import timedelta
import pytest
from fastapi.testclient import TestClient
from backend.app import create_app
from backend.domain import GST,UDYAM,valid_gstin,valid_udyam,gst_checksum
from backend.kyc import address_age,REFERENCE_DATE,compare_field

@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path/'test.sqlite3')) as c: yield c
@pytest.fixture
def body():
    return {'profile':{'employee_count':5,'sites':[{'site_id':'office','city_tier':2}]},'items':[{'product_id':'P02','site_id':'office','quantity':1},{'product_id':'P16','quantity':5},{'product_id':'P20','quantity':5}]}
def test_registry_checksums():
    assert all(map(valid_gstin,GST))
    assert all(map(valid_udyam,UDYAM))
    for value in GST:
        changed=value[:-1]+('0' if value[-1]!='0' else '1')
        assert not valid_gstin(changed)
    assert not valid_gstin('08YKZXS8189L1ZO')
@pytest.mark.parametrize('status',['Active','Cancelled','Suspended'])
def test_lookup(client,status):
    key=next(k for k,r in GST.items() if r['status']==status)
    r=client.get('/gstin/'+key)
    assert r.status_code==200
    assert r.json()['eligible']==(status=='Active')
    assert key not in r.text
    assert r.headers['cache-control']=='no-store'
def test_not_found_and_format(client):
    assert client.get('/gstin/not-valid').status_code==422
    body='99AAAXA0000A1Z'
    identifier=body+gst_checksum(body)
    assert client.get('/gstin/'+identifier).status_code==404
    key=next(iter(UDYAM))
    assert client.get('/udyam/'+key).status_code==200
    assert client.get('/udyam/UDYAM-XX-00-0000000').status_code==404
    assert client.get('/udyam/bad').status_code==422

def test_office_and_persistence(client,body):
    r=client.post('/quotes',json=body)
    assert r.status_code==201
    data=r.json(); assert data['quote']['monthly_inr']==2619
    assert data['quote']['setup_inr']==0
    assert client.get('/quotes/'+data['id']).json()==data
    revision=copy.deepcopy(body);revision['expected_version']=1;revision['items'][1]['quantity']=2
    revised=client.patch('/quotes/'+data['id'],json=revision)
    assert revised.status_code==200
    assert revised.json()['version']==2
    assert revised.json()['quote']['monthly_inr']==2244
    assert client.patch('/quotes/'+data['id'],json=revision).status_code==409

def test_reopen_database(tmp_path,body):
    path=tmp_path/'persist.sqlite3'
    with TestClient(create_app(path)) as c: saved=c.post('/quotes',json=body).json()
    with TestClient(create_app(path)) as c: assert c.get('/quotes/'+saved['id']).json()==saved
@pytest.mark.parametrize('qty',[0,-1,True,1.5,'2'])
def test_bad_quantity(client,body,qty):
    body['items'][0]['quantity']=qty
    assert client.post('/quotes/preview',json=body).status_code==422

def test_dependencies_per_site(client,body):
    body['profile']['sites'].append({'site_id':'second','city_tier':2})
    body['items'].append({'product_id':'P09','site_id':'second','quantity':1})
    assert client.post('/quotes/preview',json=body).status_code==422
    body['items'].append({'product_id':'P01','site_id':'second','quantity':1})
    r=client.post('/quotes/preview',json=body)
    assert r.status_code==200 and r.json()['setup_inr']==1500

def test_gst_cannot_be_spoofed(client,body):
    body['items']=[{'product_id':'P15','quantity':1}]
    assert client.post('/quotes/preview',json=body).status_code==422
    body['profile']['gst_status']='Active'
    assert client.post('/quotes/preview',json=body).status_code==422
    del body['profile']['gst_status']
    for status in ['Active','Suspended','Cancelled']:
        body['profile']['gstin']=next(k for k,r in GST.items() if r['status']==status)
        assert client.post('/quotes/preview',json=body).status_code==(200 if status=='Active' else 422)

def test_multi_and_tier(client,body):
    body['profile']['gstin']=next(k for k,r in GST.items() if r['status']=='Active')
    body['items']=[{'product_id':'P03','site_id':'office','quantity':1}]
    assert client.post('/quotes/preview',json=body).status_code==422
    body['profile']['sites'][0]['city_tier']=1
    assert client.post('/quotes/preview',json=body).status_code==200
    body['items']=[{'product_id':'P02','site_id':'office','quantity':1},{'product_id':'P10','site_id':'office','quantity':1}]
    assert client.post('/quotes/preview',json=body).status_code==422
    body['profile']['employee_count']=10
    body['profile']['sites'] += [{'site_id':'two','city_tier':2},{'site_id':'three','city_tier':2}]
    r=client.post('/quotes/preview',json=body)
    assert r.status_code==200
    assert [l['contract_months'] for l in r.json()['lines']]==[12,24]

@pytest.mark.parametrize('mutation',['duplicate','unknown','no_site','many_per_site','duplicate_site','empty'])
def test_invalid_selections(client,body,mutation):
    if mutation=='duplicate': body['items'].append(body['items'][0])
    if mutation=='unknown': body['items'][0]['product_id']='P99'
    if mutation=='no_site': del body['items'][0]['site_id']
    if mutation=='many_per_site': body['items'][0]['quantity']=3
    if mutation=='duplicate_site': body['profile']['sites']*=2
    if mutation=='empty': body['items']=[]
    assert client.post('/quotes/preview',json=body).status_code==422

@pytest.mark.parametrize('days,status',[(0,'valid'),(90,'valid'),(91,'review'),(-1,'review')])
def test_age_boundary(days,status):
    assert address_age((REFERENCE_DATE-timedelta(days=days)).isoformat())['status']==status

def test_comparison():
    assert compare_field('Unit 1, Main Road','unit 1 main road')=='match'
    assert compare_field('Unit 1','Unit 2')=='review'
    assert compare_field('', 'Unit 1')=='unverified'
    assert address_age('bad')['status']=='review'
