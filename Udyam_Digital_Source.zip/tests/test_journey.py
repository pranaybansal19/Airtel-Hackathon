import base64
import io
import json
import sqlite3
from datetime import datetime,timedelta,timezone
import pytest
from fastapi.testclient import TestClient
from PIL import Image
from backend.app import create_app
from backend.journey import NOTICE_VERSION
from backend.ocr import evidence,extract
from backend.domain import GST

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv("UDYAM_OPERATOR_TOKEN", "test-operator-only")
    with TestClient(create_app(tmp_path/'flow.sqlite3')) as c: yield c

def start(client):
    body={'profile':{'employee_count':5,'sites':[{'site_id':'office','city_tier':2}]},'items':[{'product_id':'P02','site_id':'office','quantity':1}]}
    quote=client.post('/quotes',json=body).json()
    r=client.post('/journeys',json={'quote_id':quote['id'],'quote_version':1,'consent':True,'notice_version':NOTICE_VERSION})
    assert r.status_code==201
    j=r.json();return j,{'X-Journey-Token':j['access_token']}

def fake_ocr(monkeypatch,text='Specimen Bill date 2026-07-01 Address proof with sufficiently long example evidence for local testing only.'):
    monkeypatch.setattr('backend.journey.extract',lambda value:{'text':('Name Test Person\nDesignation Owner\nFor business Test Business\nID no. SYN-ID-123\nValid till 2028-01-01' if value=='signatory-test' else text),'engine':'test double'})

def upload_required(client,j,h):
    for kind in ['address','signatory']:
        assert client.post('/journeys/'+j['id']+'/documents',headers=h,json={'kind':kind,'image_base64':'signatory-test' if kind=='signatory' else 'test'}).status_code==200

def test_consent_auth_and_delete(client,monkeypatch):
    assert client.post('/journeys',json={'quote_id':'bad','quote_version':1,'consent':False,'notice_version':NOTICE_VERSION}).status_code==422
    j,h=start(client)
    assert client.get('/journeys/'+j['id']).status_code==404
    assert client.get('/journeys/'+j['id'],headers={'X-Journey-Token':'wrong'}).status_code==404
    assert client.post('/journeys/'+j['id']+'/submit',headers=h).status_code==422
    assert client.delete('/journeys/'+j['id'],headers=h).status_code==200
    assert client.get('/journeys/'+j['id'],headers=h).status_code==404
    assert client.get('/quotes/'+j['quote']['id']).status_code==404

def test_complete_simulated_flow(client,monkeypatch):
    fake_ocr(monkeypatch);j,h=start(client);upload_required(client,j,h)
    base='/journeys/'+j['id']
    assert client.post(base+'/demo-action',headers={**h,'X-Operator-Token':'test-operator-only'},json={'action':'activate','note':'Trying to skip all the stages'}).status_code==409
    submitted=client.post(base+'/submit',headers=h)
    assert submitted.status_code==200 and submitted.json()['status']=='review_required'
    assert '_normalized_text' not in submitted.text
    for action,status in [('approve_review','verified_demo'),('schedule','scheduled_demo'),('activate','activated_demo')]:
        r=client.post(base+'/demo-action',headers={**h,'X-Operator-Token':'test-operator-only'},json={'action':action,'note':'Synthetic test reviewer/operator decision'})
        assert r.status_code==200,r.text
        assert r.json()['status']==status
    assert r.json()['documents']=={}
    assert all(p['status']=='activated_demo' for p in r.json()['product_status'])
    assert client.post(base+'/documents',headers=h,json={'kind':'address','image_base64':'x'}).status_code==409

def test_stale_proof_blocked(client,monkeypatch):
    fake_ocr(monkeypatch,'Specimen Electricity Bill for testing only. Bill date 2025-10-31. Other text to supply enough characters.')
    j,h=start(client);upload_required(client,j,h)
    base='/journeys/'+j['id'];client.post(base+'/submit',headers=h)
    r=client.post(base+'/demo-action',headers={**h,'X-Operator-Token':'test-operator-only'},json={'action':'approve_review','note':'Trying to approve stale address evidence'})
    assert r.status_code==422

def test_evidence_checks():
    row=next(r for r in GST.values() if r['status']=='Cancelled')
    result=evidence('gst',row['gstin']+' '+row['legal_name']+' '+row['principal_place_of_business'])
    assert result['registry_status']=='Cancelled'
    assert result['checks']
    assert evidence('gst','08YKZXS8189L1ZO')['checks']
    assert evidence('udyam','No number')['checks']
    assert evidence('address','2026-07-16')['date_check']['reason']=='future_date'

@pytest.mark.parametrize('encoded',['not base64!',base64.b64encode(b'not an image').decode()])
def test_bad_images(encoded):
    with pytest.raises(ValueError): extract(encoded)

def test_advisor_and_ai_fallback(client,monkeypatch):
    monkeypatch.delenv('UDYAM_OLLAMA_MODEL',raising=False)
    assert client.post('/advisor/interpret',json={'message':'A small clinic'}).json()['mode']=='guided_form'
    r=client.post('/advisor/recommend',json={'profile':{'employee_count':5,'sites':[{'site_id':'one','city_tier':2}]},'email_users':5,'devices':5,'budget':2000,'language':'hi'})
    assert r.status_code==200,r.text
    d=r.json();assert d['quote']['monthly_inr']==2619 and d['over_budget']
    assert d['alternatives'][0]['quote']['monthly_inr']==2119
    assert any(ord(c)>127 for c in d['explanation'])

def test_expired_evidence_cleanup(tmp_path,monkeypatch):
    path=tmp_path/'expiry.sqlite3';fake_ocr(monkeypatch)
    with TestClient(create_app(path)) as c:
        j,h=start(c);upload_required(c,j,h)
        with sqlite3.connect(path) as db:
            data=json.loads(db.execute('SELECT payload FROM journeys WHERE id=?',(j['id'],)).fetchone()[0])
            data['consent']['at']=(datetime.now(timezone.utc)-timedelta(days=31)).isoformat()
            db.execute('UPDATE journeys SET payload=? WHERE id=?',(json.dumps(data),j['id']))
        assert c.get('/journeys/'+j['id'],headers=h).json()['documents']=={}
        assert c.post('/journeys/'+j['id']+'/documents',headers=h,json={'kind':'address','image_base64':'x'}).status_code==409

def test_frontend(client):
    assert client.get('/').status_code==200
    assert 'Your business. Better connected.' in client.get('/').text
    assert client.get('/app.js').status_code==200

def test_identifier_confirmation(client,monkeypatch):
    fake_ocr(monkeypatch,'Specimen GST certificate with an unreadable identification number and sufficient words for testing.')
    j,h=start(client);base='/journeys/'+j['id']
    key=next(k for k,r in GST.items() if r['status']=='Active')
    correction={'kind':'gst','identifier':key,'reason':'The OCR misread a character; user checked the specimen'}
    assert client.post(base+'/confirm-identifier',headers=h,json=correction).status_code==422
    assert client.post(base+'/documents',headers=h,json={'kind':'gst','image_base64':'test'}).status_code==200
    r=client.post(base+'/confirm-identifier',headers=h,json=correction)
    assert r.status_code==200,r.text
    assert r.json()['registry_status']=='Active'
    assert 'original_ocr_checks' in r.json()
    assert key not in r.text
    assert r.json()['identifier_confirmation']['source'].startswith('user-confirmed')
    assert client.post(base+'/confirm-identifier',headers=h,json={**correction,'identifier':'bad'}).status_code==422

def test_inactive_correction_cannot_approve(client,monkeypatch):
    fake_ocr(monkeypatch);j,h=start(client);upload_required(client,j,h);base='/journeys/'+j['id']
    client.post(base+'/documents',headers=h,json={'kind':'gst','image_base64':'test'})
    key=next(k for k,r in GST.items() if r['status']=='Cancelled')
    assert client.post(base+'/confirm-identifier',headers=h,json={'kind':'gst','identifier':key,'reason':'Explicit test correction against the original specimen'}).status_code==200
    assert client.post(base+'/submit',headers=h).status_code==200
    assert client.post(base+'/demo-action',headers={**h,'X-Operator-Token':'test-operator-only'},json={'action':'approve_review','note':'Try to approve cancelled registration'}).status_code==422


def test_customer_cannot_self_approve(client):
    j,h=start(client)
    for action in ['approve_review','schedule','activate']:
        r=client.post('/journeys/'+j['id']+'/demo-action',headers=h,json={'action':action,'note':'Customer attempts privileged action'})
        assert r.status_code==403
    assert client.post('/journeys/'+j['id']+'/demo-action',headers=h,json={'action':'handoff','note':'Customer requests partner help'}).status_code==200


def test_signatory_name_and_expiry():
    doc=evidence('signatory','Name\nAsha Rao\nDesignation\nOwner\nFor business\nExample Store\nID no. SYN-ID-123\nValid till\n2025-01-01')
    assert doc['_signatory_name']=='Asha Rao'
    assert doc['_signatory_business']=='Example Store'
    assert any('expired' in check for check in doc['checks'])
