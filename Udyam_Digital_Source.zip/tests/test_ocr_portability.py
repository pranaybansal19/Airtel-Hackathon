from types import SimpleNamespace
import numpy as np
from PIL import Image
import pytest
from backend.tesseract_ocr import read_image

@pytest.mark.parametrize('shape',[(1,1,4),(1,4)])
def test_hough_coordinate_shapes(monkeypatch,shape):
    monkeypatch.setenv('TESSERACT_CMD','mock-tesseract')
    monkeypatch.setattr('backend.tesseract_ocr.cv2.HoughLinesP',lambda *a,**k:np.array([0,20,80,20]).reshape(shape))
    monkeypatch.setattr('backend.tesseract_ocr.subprocess.run',lambda *a,**k:SimpleNamespace(returncode=0,stdout=b'Controlled OCR test text'))
    result=read_image(Image.new('RGB',(100,100),'white'))
    assert result['preprocessing']['deskew_degrees']==0
    assert result['engine']=='Tesseract'
