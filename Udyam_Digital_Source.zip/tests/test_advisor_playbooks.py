from backend.advisor import recommend, infer_segment
from backend.domain import GST

def profile(count=5,sites=1,gst=False):
    return {'employee_count':count,'sites':[{'site_id':f's{i}','city_tier':1} for i in range(sites)],'gstin':next(k for k,v in GST.items() if v['status']=='Active') if gst else None}

def advice(kind,p,needs=None):
    return recommend(p,'professional',0,0,False,None,'en',kind,'Mobile hotspot',needs)

def test_kirana_pos_and_gst_gate():
    result=advice('kirana store',profile())
    assert result['segment']=='micro'
    assert {'P01','P19'}.issubset({x['product_id'] for x in result['items']})
    assert 'P15' in {x['product_id'] for x in result['deferred_products']}
    assert 'email' not in result['explanation']

def test_restaurant_sites_backup_cctv():
    result=advice('restaurant chain',profile(30,6,True))
    for pid in ['P02','P09','P10','P23']:
        assert len([x for x in result['items'] if x['product_id']==pid])==6
    assert result['quote']['valid']

def test_manufacturer_dedicated_firewall_and_iot():
    result=advice('manufacturer',profile(60,1,True),{'machines':8})
    assert {'P05','P09','P21','P24'}.issubset({x['product_id'] for x in result['items']})
    assert result['quote']['valid']

def test_current_pos_not_duplicated():
    result=recommend(profile(),'micro',0,0,False,None,'en','kirana','Existing POS and business internet')
    assert 'P19' not in {x['product_id'] for x in result['items']}
    assert any('replace' in q for q in result['follow_up_questions'])

def test_explicit_zero_cameras_respected():
    result=advice('restaurant chain',profile(30,6,True),{'cameras_per_site':0})
    assert 'P23' not in {x['product_id'] for x in result['items']}

def test_catalogue_coverage_by_confirmed_needs():
    seen=set()
    for kind,needs in [('kirana',{}),('clinic',{}),('clinic',{'fibre_available':False}),('clinic',{'high_bandwidth':True}),('manufacturer',{}),('manufacturer',{'high_bandwidth':True}),('restaurant chain',{'phone_channels':2,'guest_wifi':True,'static_ip':True,'mobile_lines':2,'premium_mobile_lines':2,'tollfree_numbers':1,'sms_packs':1,'backup_accounts':1,'websites':1,'machines':1,'vehicles':1})]:
        r=recommend(profile(60,3,True),'professional',5,5,False,None,'en',kind,'',needs)
        assert r['quote']['valid']
        seen.update(x['product_id'] for x in r['items'])
    # Three-site kirana is correctly multi; add a single-location retail business.
    seen.update(x['product_id'] for x in advice('kirana',profile(5,1,True))['items'])
    assert len(seen)==25,seen


def test_budget_compares_tax_inclusive_estimate():
    result=recommend(profile(),'professional',5,5,False,3000,'en','clinic','Home broadband')
    assert result['quote']['monthly_inr']==2619
    assert result['quote']['estimated_total_inr']==3090.42
    assert result['over_budget']
