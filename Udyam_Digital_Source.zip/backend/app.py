"""Local-only foundation API. Run using python -m backend.run."""
import json
import os
import sqlite3
from pathlib import Path
from uuid import uuid4
from datetime import datetime, timezone
from typing import Annotated
from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .domain import ROOT, GST, UDYAM, CATALOGUE, calculate, masked, valid_gstin, valid_udyam

Positive = Annotated[int,Field(strict=True,ge=1,le=100000)]
class Strict(BaseModel):
    model_config=ConfigDict(extra='forbid')
class Site(Strict):
    site_id: str = Field(pattern=r'^[A-Za-z0-9_-]{1,40}$')
    city_tier: Annotated[int,Field(strict=True,ge=1,le=2)]
class Profile(Strict):
    employee_count: Positive
    sites: list[Site] = Field(min_length=1,max_length=100)
    gstin: str | None = Field(default=None,max_length=15)
    @model_validator(mode='after')
    def unique_sites(self):
        if len({s.site_id for s in self.sites})!=len(self.sites): raise ValueError('Duplicate site IDs')
        return self
class Item(Strict):
    product_id: str = Field(pattern=r'^P[0-9]{2}$')
    site_id: str | None = Field(default=None,pattern=r'^[A-Za-z0-9_-]{1,40}$')
    quantity: Positive
class QuoteRequest(Strict):
    profile: Profile
    items: list[Item] = Field(min_length=1,max_length=500)
class Revision(QuoteRequest):
    expected_version: Positive

def create_app(db_path=None):
    db_path=Path(db_path or os.environ.get('UDYAM_DB',ROOT/'runtime'/'udyam.sqlite3'))
    db_path.parent.mkdir(parents=True,exist_ok=True)
    def connect():
        return sqlite3.connect(db_path,timeout=10)
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS quotes (id TEXT, version INTEGER, payload TEXT NOT NULL, PRIMARY KEY(id,version))')
    app=FastAPI(title='Udyam Digital — local prototype',version='0.1.0')
    @app.exception_handler(RequestValidationError)
    async def validation_error(request,exc):
        # Omit rejected input values, which may contain identifiers.
        return JSONResponse(status_code=422,content={'detail':[{'loc':e['loc'],'type':e['type'],'msg':e['msg']} for e in exc.errors()]})
    @app.middleware('http')
    async def privacy_headers(request,call_next):
        response=await call_next(request)
        response.headers['Cache-Control']='no-store'
        return response
    @app.get('/health')
    def health(): return {'status':'ok','mode':'synthetic local prototype'}
    @app.get('/catalogue')
    def catalogue(): return list(CATALOGUE.values())
    @app.get('/gstin/{identifier}')
    def gst_lookup(identifier:str):
        value=identifier.strip().upper()
        if not valid_gstin(value): raise HTTPException(422,'Invalid GSTIN format or checksum')
        row=GST.get(value)
        if not row: raise HTTPException(404,'GSTIN not found')
        return {'identifier':masked(value),'status':row['status'],'eligible':row['status']=='Active','legal_name':row['legal_name'],'trade_name':row['trade_name'],'source':'synthetic registry'}
    @app.get('/udyam/{identifier}')
    def udyam_lookup(identifier:str):
        value=identifier.strip().upper()
        if not valid_udyam(value): raise HTTPException(422,'Invalid Udyam format')
        row=UDYAM.get(value)
        if not row: raise HTTPException(404,'Udyam not found')
        return {'identifier':masked(value),'enterprise_name':row['enterprise_name'],'enterprise_type':row['enterprise_type'],'source':'synthetic registry'}
    def priced(body):
        result=calculate(body.profile.model_dump(),[x.model_dump() for x in body.items])
        if not result['valid']: raise HTTPException(422,result['errors'])
        return result
    @app.post('/quotes/preview')
    def preview(body:QuoteRequest): return priced(body)
    @app.post('/quotes',status_code=201)
    def save(body:QuoteRequest):
        result=priced(body); qid=str(uuid4())
        payload=dict(id=qid,version=1,created_at=datetime.now(timezone.utc).isoformat(),quote=result)
        # Persist only quote results, not supplied GSTIN or customer profile.
        with connect() as db: db.execute('INSERT INTO quotes VALUES (?,?,?)',(qid,1,json.dumps(payload)))
        return payload
    @app.get('/quotes/{qid}')
    def get(qid:str):
        with connect() as db: row=db.execute('SELECT payload FROM quotes WHERE id=? ORDER BY version DESC LIMIT 1',(qid,)).fetchone()
        if not row: raise HTTPException(404,'Quote not found')
        return json.loads(row[0])
    @app.patch('/quotes/{qid}')
    def revise(qid:str,body:Revision):
        result=priced(body)
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current=db.execute('SELECT MAX(version) FROM quotes WHERE id=?',(qid,)).fetchone()[0]
            if current is None: raise HTTPException(404,'Quote not found')
            if current != body.expected_version: raise HTTPException(409,'Quote changed; reload latest version')
            payload=dict(id=qid,version=current+1,created_at=datetime.now(timezone.utc).isoformat(),quote=result)
            db.execute('INSERT INTO quotes VALUES (?,?,?)',(qid,current+1,json.dumps(payload)))
        return payload
    from .journey import install
    install(app, connect, Profile)
    from fastapi.staticfiles import StaticFiles
    app.mount("/", StaticFiles(directory=ROOT/"frontend", html=True), name="frontend")
    return app
