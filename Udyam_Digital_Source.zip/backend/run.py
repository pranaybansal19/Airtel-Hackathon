from pathlib import Path
import sys
import os
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'.dependencies'))
import uvicorn
from .app import create_app
if __name__=='__main__':
    os.environ.setdefault('UDYAM_OLLAMA_MODEL','qwen2.5:1.5b')
    uvicorn.run(create_app(),host='127.0.0.1',port=8000,access_log=False)
