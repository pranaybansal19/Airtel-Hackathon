"""Consent-bound local journey, evidence review and explicitly simulated fulfilment."""
import hashlib
import json
import secrets
import os
from datetime import datetime,timedelta,timezone
from typing import Literal
from fastapi import APIRouter,Header,HTTPException
from pydantic import Field,BaseModel,ConfigDict
from .domain import CATALOGUE,GST,UDYAM,valid_gstin,valid_udyam,masked
from .kyc import normalize
from .ocr import extract,evidence,OCRUnavailable
from .advisor import recommend,interpret,infer_segment

NOTICE_VERSION='2026-11-demo-v1'
NOTICE='Use these synthetic documents to check business details and prepare a demo order. OCR runs on this computer. Raw uploads are deleted immediately after OCR. Extracted evidence is removed on review completion, withdrawal, or after 30 days (cleanup runs on API access/startup). No government verification, payment or installation occurs. You may withdraw and delete this journey.'
def now(): return datetime.now(timezone.utc).isoformat()
def public(value):
    if isinstance(value,dict): return {k:public(v) for k,v in value.items() if not k.startswith('_')}
    if isinstance(value,list): return [public(v) for v in value]
    return value

class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class Start(Strict):
    quote_id:str
    quote_version:int=Field(strict=True,ge=1)
    consent:bool=Field(strict=True)
    notice_version:str
    partner_referral:str=Field(default='',max_length=80)
class Upload(Strict):
    kind:Literal['gst','udyam','address','signatory']
    image_base64:str=Field(max_length=8500000)
class Correction(Strict):
    kind:Literal['gst','udyam']
    identifier:str=Field(min_length=1,max_length=30)
    reason:str=Field(min_length=10,max_length=300)
class Action(Strict):
    action:Literal['approve_review','schedule','activate','handoff']
    note:str=Field(min_length=10,max_length=500)
class Message(Strict):
    message:str=Field(min_length=1,max_length=2000)
class Extracted(Strict):
    business_type:str|None=None
    employee_count:int|None=Field(default=None,ge=1,le=100000)
    num_sites:int|None=Field(default=None,ge=1,le=100)
    budget:int|None=Field(default=None,ge=0)
    email_users:int|None=Field(default=None,ge=0)
    devices:int|None=Field(default=None,ge=0)

def install(app,connect,Profile):
    class Needs(Strict):
        fibre_available:bool|None=None
        dedicated_bandwidth:bool=False
        high_bandwidth:bool=False
        firewall:bool=False
        guest_wifi:bool=False
        static_ip:bool=False
        whatsapp:bool=False
        cameras_per_site:int|None=Field(default=None,strict=True,ge=0,le=100000)
        pos_counters:int|None=Field(default=None,strict=True,ge=0,le=100000)
        phone_channels:int|None=Field(default=None,strict=True,ge=0,le=100000)
        mobile_lines:int|None=Field(default=None,strict=True,ge=0,le=100000)
        premium_mobile_lines:int|None=Field(default=None,strict=True,ge=0,le=100000)
        tollfree_numbers:int|None=Field(default=None,strict=True,ge=0,le=100000)
        sms_packs:int|None=Field(default=None,strict=True,ge=0,le=100000)
        backup_accounts:int|None=Field(default=None,strict=True,ge=0,le=100000)
        websites:int|None=Field(default=None,strict=True,ge=0,le=100000)
        machines:int|None=Field(default=None,strict=True,ge=0,le=100000)
        vehicles:int|None=Field(default=None,strict=True,ge=0,le=100000)
    class Advice(Strict):
        profile:Profile
        segment:Literal['micro','professional','multi','manufacturing']='professional'
        email_users:int=Field(default=0,strict=True,ge=0,le=100000)
        devices:int=Field(default=0,strict=True,ge=0,le=100000)
        resilience:bool=False
        budget:int|None=Field(default=None,strict=True,ge=0)
        language:Literal['en','hi']='en'
        current_setup:str=Field(default='',max_length=300)
        business_type:str=Field(default='',max_length=150)
        needs:Needs=Field(default_factory=Needs)
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS journeys(id TEXT PRIMARY KEY,token_hash TEXT NOT NULL,payload TEXT NOT NULL)')
    def cleanup():
        with connect() as db:
            rows=db.execute('SELECT id,payload FROM journeys').fetchall()
            for jid,raw in rows:
                data=json.loads(raw)
                if datetime.fromisoformat(data['consent']['at'])<datetime.now(timezone.utc)-timedelta(days=30) and data.get('documents'):
                    data['documents']={};data['evidence_expired']=True
                    if data['status'] in ['documents_pending','review_required']: data['status']='documents_pending'
                    db.execute('UPDATE journeys SET payload=? WHERE id=?',(json.dumps(data),jid))
    cleanup()
    def load(db,jid,token):
        row=db.execute('SELECT token_hash,payload FROM journeys WHERE id=?',(jid,)).fetchone()
        if not row or not token or not secrets.compare_digest(row[0],hashlib.sha256(token.encode()).hexdigest()): raise HTTPException(404,'Journey not found')
        return json.loads(row[1])
    def store(db,data): db.execute('UPDATE journeys SET payload=? WHERE id=?',(json.dumps(data),data['id']))
    def event(data,label,note): data['events'].append({'at':now(),'status':label,'note':note})
    @app.get('/privacy')
    def privacy(): return {'version':NOTICE_VERSION,'notice':NOTICE}
    @app.post('/advisor/interpret')
    def parse(body:Message):
        result=interpret(body.message,Extracted.model_json_schema())
        if result['profile'] is not None:
            try:
                result['profile']=Extracted.model_validate(result['profile']).model_dump()
                result['segment']=infer_segment(result['profile'].get('business_type') or '',result['profile'].get('num_sites') or 1)
                missing=[k for k,v in result['profile'].items() if v is None]
                result['missing_fields']=missing
                if missing: result['message']='Please confirm the missing business details in the form: '+', '.join(missing)
                else: result['message']='Business facts extracted locally. Review them before requesting a bundle.'
            except ValueError: result={'mode':'guided_form','profile':None,'message':'AI extraction was invalid; use the form.'}
        return result
    @app.post('/advisor/recommend')
    def advice(body:Advice):
        return recommend(body.profile.model_dump(),body.segment,body.email_users,body.devices,body.resilience,body.budget,body.language,body.business_type,body.current_setup,body.needs.model_dump(exclude_none=True))
    @app.post('/journeys',status_code=201)
    def start(body:Start):
        if not body.consent or body.notice_version!=NOTICE_VERSION: raise HTTPException(422,'Current affirmative consent is required')
        token=secrets.token_urlsafe(32);jid=secrets.token_hex(16)
        with connect() as db:
            row=db.execute('SELECT version,payload FROM quotes WHERE id=? ORDER BY version DESC LIMIT 1',(body.quote_id,)).fetchone()
            if not row: raise HTTPException(404,'Quote not found')
            if row[0]!=body.quote_version: raise HTTPException(409,'Quote changed; accept the latest version')
            quote=json.loads(row[1])
            data={'id':jid,'status':'documents_pending','quote':quote,'consent':{'version':NOTICE_VERSION,'at':now(),'purpose':'Synthetic business KYC and demo order'},'documents':{},'events':[],'partner_referral':body.partner_referral,'simulation':True,'handoff':None}
            event(data,'documents_pending','Quote accepted; upload evidence. This is a simulated order.')
            db.execute('INSERT INTO journeys VALUES(?,?,?)',(jid,hashlib.sha256(token.encode()).hexdigest(),json.dumps(data)))
        return {**public(data),'access_token':token}
    @app.get('/journeys/{jid}')
    def get(jid:str,x_journey_token:str|None=Header(default=None)):
        cleanup()
        with connect() as db: return public(load(db,jid,x_journey_token))
    @app.post('/journeys/{jid}/documents')
    def upload(jid:str,body:Upload,x_journey_token:str|None=Header(default=None)):
        cleanup()
        with connect() as db:
            data=load(db,jid,x_journey_token)
            if datetime.fromisoformat(data['consent']['at'])<datetime.now(timezone.utc)-timedelta(days=30): raise HTTPException(409,'Consent window expired; delete and start a new journey')
            if data['status'] not in ['documents_pending','review_required']: raise HTTPException(409,'Evidence collection is closed')
        try: output=extract(body.image_base64)
        except ValueError as exc: raise HTTPException(422,str(exc))
        except (OCRUnavailable,TimeoutError) as exc: raise HTTPException(503,str(exc))
        doc=evidence(body.kind,output['text'])
        doc['engine']=output.get('engine','unknown')
        doc['preprocessing']=output.get('preprocessing',{})
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            data=load(db,jid,x_journey_token)
            if data['status'] not in ['documents_pending','review_required']: raise HTTPException(409,'Evidence collection is closed')
            data['documents'][body.kind]=doc; data['status']='documents_pending'
            event(data,'documents_pending',body.kind+' extracted locally; original upload deleted')
            store(db,data)
        return public(doc)
    @app.post('/journeys/{jid}/confirm-identifier')
    def confirm_identifier(jid:str,body:Correction,x_journey_token:str|None=Header(default=None)):
        cleanup()
        value=body.identifier.strip().upper()
        registry=GST if body.kind=='gst' else UDYAM
        validator=valid_gstin if body.kind=='gst' else valid_udyam
        if not validator(value): raise HTTPException(422,'Invalid identifier format or checksum')
        if value not in registry: raise HTTPException(404,'Identifier not found in synthetic registry')
        with connect() as db:
            db.execute('BEGIN IMMEDIATE');data=load(db,jid,x_journey_token)
            if data['status'] not in ['documents_pending','review_required']: raise HTTPException(409,'Evidence collection is closed')
            original=data['documents'].get(body.kind)
            if not original: raise HTTPException(422,'Upload this document before confirming its identifier')
            corrected=evidence(body.kind,original.get('_normalized_text','')+'\n'+value)
            corrected['identifier_confirmation']={'identifier':masked(value),'reason':body.reason,'at':now(),'source':'user-confirmed; not automatically OCR-verified'}
            corrected['original_ocr_checks']=original.get('original_ocr_checks',original['checks'])
            corrected['checks'].append('User-confirmed identifier: reviewer must check it against the original specimen')
            data['documents'][body.kind]=corrected;data['status']='documents_pending'
            event(data,'documents_pending','Identifier explicitly confirmed for '+body.kind+'; original OCR concerns retained')
            store(db,data)
        return public(corrected)
    @app.post('/journeys/{jid}/submit')
    def submit(jid:str,x_journey_token:str|None=Header(default=None)):
        cleanup()
        with connect() as db:
            db.execute('BEGIN IMMEDIATE'); data=load(db,jid,x_journey_token)
            if data['status']!='documents_pending': raise HTTPException(409,'Cannot submit at this stage')
            required={'address','signatory'}
            if any(CATALOGUE[l['product_id']]['requires_gstin']=='Y' for l in data['quote']['quote']['lines']): required.add('gst')
            missing=required-data['documents'].keys()
            if missing: raise HTTPException(422,'Missing documents: '+', '.join(sorted(missing)))
            docs=data['documents'];checks=[]
            for doc in docs.values(): checks.extend(doc['checks'])
            key=docs.get('gst',{}).get('_registry_key')
            if key:
                row=GST[key]
                address=docs.get('address',{}).get('_normalized_text','')
                if normalize(row['principal_place_of_business']) not in address: checks.append('Address proof could not be matched exactly with GST registry')
                ukey=docs.get('udyam',{}).get('_udyam_key')
                if ukey and normalize(UDYAM[ukey]['enterprise_name']) not in [normalize(row['trade_name']),normalize(row['legal_name'])]: checks.append('GST and Udyam enterprise names differ')
            data['review_checks']=checks;data['status']='review_required'
            data['handoff']={'queue':'KYC review','reason':'Signing authority and extraction require reviewer confirmation','at':now()}
            # Conservative documentary fast path; never claims real identity/authority verification.
            signatory=docs.get('signatory',{})
            if key:
                if not normalize(signatory.get('_signatory_name','')) or normalize(signatory.get('_signatory_name','')) not in normalize(GST[key]['legal_name']):
                    checks.append('Signatory name does not match the registry legal name; authority evidence required')
                if normalize(signatory.get('_signatory_business','')) not in [normalize(GST[key]['legal_name']),normalize(GST[key]['trade_name'])]:
                    checks.append('Signatory business does not match registry')
            complete={'gst','udyam','address','signatory'}.issubset(docs)
            binding=data['quote']['quote'].get('gst_binding')
            binding_ok=not binding or (key and hashlib.sha256(key.encode()).hexdigest()==binding)
            if complete and key and docs['gst'].get('registry_status')=='Active' and docs['udyam'].get('_udyam_key') and not checks and binding_ok and docs['address'].get('date_check',{}).get('status')=='valid':
                data['status']='verified_demo';data['handoff']=None
                data['documentary_result']='Automated synthetic document checks passed; not government identity or signing-authority verification'
                data['documents']={}
                event(data,'verified_demo',data['documentary_result']+'; extracted evidence removed')
            else:
                event(data,'review_required','Document checks need review; no automatic identity approval')
            store(db,data)
        return public(data)
    @app.post('/journeys/{jid}/demo-action')
    def advance(jid:str,body:Action,x_journey_token:str|None=Header(default=None),x_operator_token:str|None=Header(default=None)):
        if body.action != 'handoff':
            operator = os.environ.get('UDYAM_OPERATOR_TOKEN', '')
            if not operator or not x_operator_token or not secrets.compare_digest(operator, x_operator_token):
                raise HTTPException(403, 'Separate operator credential required; customer access cannot approve or activate')
        cleanup()
        with connect() as db:
            db.execute('BEGIN IMMEDIATE');data=load(db,jid,x_journey_token)
            if body.action=='handoff':
                data['handoff']={'queue':'Partner assistance','reason':body.note,'at':now()};event(data,data['status'],'Assistance requested: '+body.note)
            elif body.action=='approve_review':
                if data['status']!='review_required': raise HTTPException(409,'Review submission required')
                docs=data['documents']
                if not {'address','signatory'}.issubset(docs): raise HTTPException(422,'Evidence missing or expired; upload and submit again')
                if docs.get('address',{}).get('date_check',{}).get('reason') in ['stale_address_proof','future_date']: raise HTTPException(422,'Replace the dated address proof before review approval')
                if any('expired' in check or 'Invalid signatory expiry' in check for check in docs.get('signatory',{}).get('checks',[])):
                    raise HTTPException(422,'Replace missing, invalid or expired signatory expiry evidence')
                if docs.get('gst',{}).get('registry_status') in ['Cancelled','Suspended']: raise HTTPException(422,'Inactive GST evidence cannot be approved')
                binding=data['quote']['quote'].get('gst_binding')
                evidence_key=docs.get('gst',{}).get('_registry_key')
                if binding and evidence_key and hashlib.sha256(evidence_key.encode()).hexdigest()!=binding: raise HTTPException(422,'GST evidence belongs to a different business than the accepted quote')
                requires=any(CATALOGUE[l['product_id']]['requires_gstin']=='Y' for l in data['quote']['quote']['lines'])
                if requires and docs.get('gst',{}).get('registry_status')!='Active': raise HTTPException(422,'GST-required products need readable active GST evidence')
                data['status']='verified_demo';data['documents']={};data['handoff']=None
                event(data,'verified_demo','SIMULATED reviewer approval; evidence removed. '+body.note)
            elif body.action=='schedule':
                if data['status']!='verified_demo': raise HTTPException(409,'Demo review approval required')
                data['status']='scheduled_demo';start=datetime.now(timezone.utc)
                data['product_status']=[{'product_id':l['product_id'],'site_id':l['site_id'],'status':'scheduled_demo','estimated_date':(start+timedelta(days=l['typical_install_days'])).date().isoformat()} for l in data['quote']['quote']['lines']]
                event(data,'scheduled_demo','SIMULATED serviceability confirmation and scheduling. '+body.note)
            elif body.action=='activate':
                if data['status']!='scheduled_demo': raise HTTPException(409,'Demo scheduling required')
                data['status']='activated_demo'
                for p in data['product_status']: p['status']='activated_demo'
                event(data,'activated_demo','SIMULATED activation; no real service or payment. '+body.note)
            store(db,data)
        return public(data)
    @app.delete('/journeys/{jid}')
    def delete(jid:str,x_journey_token:str|None=Header(default=None)):
        with connect() as db:
            db.execute('BEGIN IMMEDIATE');data=load(db,jid,x_journey_token)
            db.execute('DELETE FROM journeys WHERE id=?',(jid,))
            # Quote records have no direct identifiers, but remove the linked versions too.
            db.execute('DELETE FROM quotes WHERE id=?',(data['quote']['id'],))
        return {'deleted':True,'consent_withdrawn':True}
