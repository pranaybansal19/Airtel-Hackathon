"""Catalogue rules and synthetic registry validation; no network calls."""
import csv
import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'YTL_TrackA_Udyam_Digital_Data'

def load(name, key):
    with (DATA/name).open(encoding='utf-8-sig', newline='') as f:
        return {r[key]:r for r in csv.DictReader(f)}

CATALOGUE = load('product_catalogue.csv', 'product_id')
GST = load('mock_gstin_registry.csv', 'gstin')
UDYAM = load('mock_udyam_registry.csv', 'udyam_number')
ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def gst_checksum(body):
    factor, total = 2, 0
    for char in reversed(body):
        value = ALPHABET.index(char) * factor
        total += value // 36 + value % 36
        factor = 3 - factor
    return ALPHABET[(36-total%36)%36]

def valid_gstin(value):
    # Synthetic pack explicitly permits X as PAN entity character.
    return bool(re.fullmatch(r'[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]',value)) and value[-1] == gst_checksum(value[:-1])

def valid_udyam(value):
    # District 00 is intentional in this synthetic dataset.
    return bool(re.fullmatch(r'UDYAM-[A-Z]{2}-[0-9]{2}-[0-9]{7}',value))

def masked(value):
    return '*' * max(0,len(value)-4) + value[-4:]

def calculate(profile, items):
    errors, lines = [], []
    sites = {s['site_id']:s for s in profile['sites']}
    gstin = (profile.get('gstin') or '').strip().upper()
    active_gst = valid_gstin(gstin) and GST.get(gstin,{}).get('status')=='Active'
    seen=set()
    if not items: errors.append('At least one product is required')
    for item in items:
        pid, sid, qty = item['product_id'], item.get('site_id'), item['quantity']
        key=(pid,sid)
        if key in seen: errors.append(f'{pid}: duplicate product/site; combine quantities')
        seen.add(key)
        p=CATALOGUE.get(pid)
        if not p: errors.append(f'{pid}: unknown product'); continue
        if type(qty) is not int or qty < 1: errors.append(f'{pid}: invalid quantity'); continue
        if sid is not None and sid not in sites: errors.append(f'{pid}: unknown site'); continue
        deps=p['requires_one_of'].split('|') if p['requires_one_of'] else []
        if (p['unit']=='per site' or deps) and sid is None:
            errors.append(f'{pid}: a site allocation is required'); continue
        if p['unit']=='per site' and qty!=1: errors.append(f'{pid}: use one unit per selected site')
        tiers={str(sites[sid]['city_tier'])} if sid else {str(s['city_tier']) for s in sites.values()}
        if not tiers.issubset(set(p['available_city_tiers'].split(';'))): errors.append(f'{pid}: unavailable city tier')
        if profile['employee_count']<int(p['min_employees']): errors.append(f'{pid}: minimum employee count not met')
        if len(sites)<int(p['min_sites']): errors.append(f'{pid}: minimum site count not met')
        if p['requires_gstin']=='Y' and not active_gst: errors.append(f'{pid}: active registry-verified GSTIN required')
        if deps and not any(x['product_id'] in deps and x.get('site_id')==sid and type(x['quantity']) is int and x['quantity']>0 for x in items): errors.append(f'{pid}: missing connectivity dependency at selected site')
        lines.append(dict(product_id=pid,site_id=sid,name=p['product_name'],unit=p['unit'],quantity=qty,unit_monthly_inr=int(p['price_min_inr_per_month']),monthly_inr=qty*int(p['price_min_inr_per_month']),setup_inr=qty*int(p['one_time_setup_inr']),contract_months=int(p['min_contract_months']),typical_install_days=int(p['typical_install_days'])))
    if errors: return {'valid':False,'errors':errors}
    monthly=sum(x['monthly_inr'] for x in lines)
    setup=sum(x['setup_inr'] for x in lines)
    upper=sum(x['quantity']*int(CATALOGUE[x['product_id']]['price_max_inr_per_month']) for x in lines)
    # Tax is an explicitly disclosed modelling assumption, not a tax determination.
    tax=round(monthly*0.18,2)
    return dict(valid=True,errors=[],lines=lines,monthly_inr=monthly,setup_inr=setup,monthly_range_inr=[monthly,upper],estimated_tax_rate=0.18,estimated_tax_inr=tax,estimated_total_inr=round(monthly+tax,2),estimated_total_range_inr=[round(monthly*1.18,2),round(upper*1.18,2)],estimated_setup_tax_inr=round(setup*0.18,2),estimated_install_days=max(x['typical_install_days'] for x in lines),taxes='Illustrative 18% assumption on all lines; final classification and invoice require confirmation',serviceability='Pending confirmation',pricing_policy='Starting estimate at catalogue minimum; full range disclosed because catalogue supplies no tariff-selection conditions. Final offer requires confirmation.',gst_verified=bool(active_gst),gst_binding=hashlib.sha256(gstin.encode()).hexdigest() if active_gst else None)
