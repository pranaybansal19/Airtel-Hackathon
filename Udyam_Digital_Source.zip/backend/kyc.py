"""Deterministic review helpers; these do not perform OCR or approve identity."""
from datetime import date
import re
REFERENCE_DATE=date(2026,7,15)
def address_age(value, today=REFERENCE_DATE):
    try: age=(today-date.fromisoformat(value)).days
    except (ValueError,TypeError): return {'status':'review','reason':'invalid_date'}
    if age<0: return {'status':'review','reason':'future_date','age_days':age}
    return {'status':'valid' if age<=90 else 'review','reason':'within_90_days' if age<=90 else 'stale_address_proof','age_days':age}
def normalize(value):
    return re.sub(r'[^a-z0-9]','',value.casefold())
def compare_field(document,registry):
    if not document or not registry: return 'unverified'
    return 'match' if normalize(document)==normalize(registry) else 'review'
