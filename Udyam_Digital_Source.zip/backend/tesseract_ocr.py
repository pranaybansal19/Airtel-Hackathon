"""Cross-platform OCR with derived-copy preprocessing; never alters supplied files."""
import os
import shutil
import subprocess
from pathlib import Path
import cv2
import numpy as np

def read_image(image):
    executable=os.environ.get('TESSERACT_CMD') or shutil.which('tesseract')
    if not executable and Path('C:/Program Files/Tesseract-OCR/tesseract.exe').exists():
        executable='C:/Program Files/Tesseract-OCR/tesseract.exe'
    if not executable: raise RuntimeError('Install Tesseract OCR and its English language data; see README')
    pixels=np.asarray(image.convert('RGB'))
    # Red-channel threshold suppresses pale/red specimen watermarks on a derived copy.
    mono=np.where(pixels[:,:,0]<160,0,255).astype('uint8')
    edges=cv2.Canny(mono,50,150)
    lines=cv2.HoughLinesP(edges,1,np.pi/180,100,minLineLength=min(mono.shape)//5,maxLineGap=20)
    angles=[]
    if lines is not None:
        for x1,y1,x2,y2 in np.asarray(lines).reshape(-1,4):
            angle=np.degrees(np.arctan2(y2-y1,x2-x1))
            if abs(angle)<15: angles.append(angle)
            elif abs(abs(angle)-90)<15: angles.append(angle-90 if angle>0 else angle+90)
    angle=float(np.median(angles)) if angles else 0.0
    h,w=mono.shape
    matrix=cv2.getRotationMatrix2D((w/2,h/2),angle,1)
    clean=cv2.warpAffine(mono,matrix,(w,h),borderValue=255)
    ok,encoded=cv2.imencode('.png',clean)
    if not ok: raise RuntimeError('Unable to prepare image')
    result=subprocess.run([executable,'stdin','stdout','-l','eng','--psm','6'],input=encoded.tobytes(),capture_output=True,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode: raise RuntimeError('Tesseract extraction failed; check English language data')
    return {'text':result.stdout.decode('utf-8',errors='replace'),'engine':'Tesseract','confidence_available':False,'preprocessing':{'deskew_degrees':round(angle,2),'watermark_suppression':'red-channel threshold on derived copy'}}
