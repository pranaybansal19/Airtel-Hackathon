"""Local image OCR. Raw images are removed immediately after extraction."""
import base64
import binascii
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
from datetime import date
from PIL import Image,UnidentifiedImageError
from .domain import ROOT, GST, UDYAM,valid_gstin,masked
from .kyc import address_age,normalize

class OCRUnavailable(Exception): pass

def extract(encoded):
    try: raw=base64.b64decode(encoded,validate=True)
    except (ValueError,binascii.Error): raise ValueError('Invalid base64 image')
    if len(raw)>6*1024*1024: raise ValueError('Image must be at most 6 MB')
    try:
        im=Image.open(io.BytesIO(raw))
        if im.format not in ('PNG','JPEG'): raise ValueError('PNG or JPEG required')
        if im.width*im.height>16000000 or max(im.size)>10000: raise ValueError('Image dimensions too large')
        im.load()
    except (UnidentifiedImageError,OSError,Image.DecompressionBombError): raise ValueError('Unreadable image')
    if os.environ.get('UDYAM_OCR_ENGINE','tesseract') != 'windows':
        from .tesseract_ocr import read_image
        try:
            return read_image(im)
        except (RuntimeError,subprocess.TimeoutExpired) as exc:
            raise OCRUnavailable(str(exc))
        finally:
            im.close()
    if os.name!='nt': raise OCRUnavailable('Windows OCR selected on a non-Windows host; use tesseract')
    folder=ROOT/'runtime'/'ocr';folder.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=folder,suffix='.png',delete=False) as fp:
        path=Path(fp.name)
    try:
        im=im.convert('RGB');im.thumbnail((2500,2500));im.save(path)
        try:
            result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'backend/windows_ocr.ps1'),'-ImagePath',str(path)],capture_output=True,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired: raise OCRUnavailable('Local OCR timed out; retry a smaller image')
        if result.returncode: raise OCRUnavailable('Local OCR failed; check Windows English OCR support')
        try: data=json.loads(result.stdout.decode('utf-8-sig'))
        except (UnicodeError,ValueError): raise OCRUnavailable('Local OCR returned an unreadable result')
    finally:
        im.close()
        # Windows can briefly retain a handle after the OCR subprocess exits.
        for attempt in range(10):
            try:
                path.unlink(missing_ok=True)
                break
            except PermissionError:
                if attempt==9: raise OCRUnavailable('Temporary image cleanup failed; local operator attention required')
                time.sleep(0.1*(attempt+1))
    text=data['text']
    return {'text':text,'engine':data['engine'],'confidence_available':False}

def evidence(kind,text):
    # OCR line ordering differs across layouts. Preserve dates/candidates as evidence,
    # never silently change I/O into 1/0 or infer an unreadable identifier.
    ids=re.findall(r'\b[0-9]{2}[A-Z0-9]{13}\b',text.upper())
    udyam=[re.sub(r'\s+','',x) for x in re.findall(r'UDYAM\s*-\s*[A-Z]{2}\s*-\s*[0-9]{2}\s*-\s*[0-9]{7}',text.upper())]
    dates=re.findall(r'\b20[0-9]{2}-[0-9]{2}-[0-9]{2}\b',text)
    result={'kind':kind,'confidence_available':False,'character_count':len(text),'date_candidates':dates,'identifier_candidates':[masked(x) for x in ids+udyam],'checks':[]}
    if len(text)<80: result['checks'].append('Too little readable text; request a clearer image')
    if kind=='gst':
        found=list(dict.fromkeys(x for x in ids if valid_gstin(x) and x in GST))
        if len(found)!=1: result['checks'].append('GSTIN not reliably extracted; correct or re-upload for review')
        else:
            row=GST[found[0]]
            result['registry_status']=row['status']
            if row['status']!='Active': result['checks'].append('GST registry status is '+row['status'])
            if normalize(row['legal_name']) not in normalize(text): result['checks'].append('Legal name could not be matched exactly; review OCR or document')
            result['_registry_key']=found[0]
    if kind=='udyam':
        if len(udyam)!=1 or udyam[0] not in UDYAM: result['checks'].append('Udyam number missing, unreadable or not found')
        else: result['_udyam_key']=udyam[0]
    if kind=='address':
        if len(dates)!=1: result['checks'].append('Bill date needs review')
        else:
            result['date_check']=address_age(dates[0])
            if result['date_check']['status']!='valid': result['checks'].append(result['date_check']['reason'])
    if kind=='signatory':
        def field(label,next_label):
            match=re.search(label+r'\s*[:.]?\s*(.*?)\s*'+next_label,text,re.I|re.S)
            return re.sub(r'\s+',' ',match.group(1)).strip() if match else ''
        result['_signatory_name']=field(r'\bName',r'Designation')
        result['_signatory_business']=field(r'For business',r'ID no')
        expiry=re.search(r'Valid till\s*[:.]?\s*(20\d{2}-\d{2}-\d{2})',text,re.I)
        result['expiry']=expiry.group(1) if expiry else None
        result['name_extracted']=bool(result['_signatory_name'])
        result['business_extracted']=bool(result['_signatory_business'])
        if not result['_signatory_name'] or not result['_signatory_business']: result['checks'].append('Signatory name or business unreadable')
        try:
            if not result['expiry'] or date.fromisoformat(result['expiry'])<date(2026,7,15): result['checks'].append('Signatory ID expiry missing or expired')
        except ValueError: result['checks'].append('Invalid signatory expiry date')
    # These strings are private intermediate comparison evidence, not exposed by API.
    result['_normalized_text']=normalize(text)
    return result
