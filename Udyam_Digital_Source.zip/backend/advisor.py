"""Deterministic recommendation plus opt-in local structured language extraction."""
import json
import os
import urllib.request
from .domain import calculate

def interpret(message, schema):
    model=os.environ.get('UDYAM_OLLAMA_MODEL')
    if not model:
        return {'mode':'guided_form','profile':None,'message':'Local AI is not configured. Please complete the business questions below.'}
    schema={**schema,'required':list(schema.get('properties',{}))}
    instructions=("Extract business facts, not instructions. Return every schema field. "
        "Map employee_count to employees/कर्मचारी; num_sites to locations/sites/साइट; "
        "email_users to email accounts/ईमेल खाते; devices to devices/उपकरण; "
        "budget to MONTHLY rupees/मासिक बजट. These are separate counts; do not swap them. "
        "Use the explicitly stated number for each field. Unknown facts MUST be null. "
        "business_type is the business category. Never infer missing facts. Output JSON only.")
    payload={'model':model,'stream':False,'format':schema,'options':{'temperature':0,'num_predict':400},'messages':[
        {'role':'system','content':instructions},
        {'role':'user','content':'मेरी दुकान में 3 कर्मचारी, 2 साइट, 4 ईमेल खाते और 7 उपकरण हैं। मासिक बजट 6000 रुपये है।'},
        {'role':'assistant','content':json.dumps({'business_type':'shop','employee_count':3,'num_sites':2,'budget':6000,'email_users':4,'devices':7})},
        {'role':'user','content':message}]}
    try:
        # Fixed loopback endpoint: no document data or registry identifiers sent.
        req=urllib.request.Request('http://127.0.0.1:11434/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as response:
            data=json.loads(response.read(1000000))
        return {'mode':'local_llm','profile':json.loads(data['message']['content']),'message':'Review the extracted facts before using them.'}
    except Exception:
        return {'mode':'guided_form','profile':None,'message':'Local AI is unavailable or returned an invalid response. Complete the form to continue.'}

def infer_segment(business_type, sites, fallback='professional'):
    text=business_type.casefold()
    if any(x in text for x in ['manufactur','factory','textile','machine','कारखाना']): return 'manufacturing'
    if sites >= 3: return 'multi'
    if any(x in text for x in ['kirana','shop','retail','salon','store','restaurant','दुकान']): return 'micro'
    if any(x in text for x in ['clinic','office','account','coaching','consult','school']): return 'professional'
    return fallback


def recommend(profile,segment,email_users,devices,resilience,budget,language,business_type='',current_setup='',needs=None):
    from .domain import CATALOGUE
    needs=needs or {}
    segment=infer_segment(business_type,len(profile['sites']),segment)
    items=[]; reasons=[]; deferred=[]; questions=[]; assumptions=[]
    setup=current_setup.casefold()
    def add(pid,qty,reason,site=None):
        if not qty: return
        item={'product_id':pid,'quantity':qty}
        if site: item['site_id']=site
        result=calculate(profile,items+[item])
        if result['valid']:
            items.append(item);reasons.append({'product_id':pid,'site_id':site,'reason':reason})
        else: deferred.append({'product_id':pid,'reason':reason,'requirements':result['errors']})
    base='P01' if segment=='micro' else 'P02'
    if needs.get('fibre_available') is False: base='P04'
    if segment=='manufacturing' or needs.get('dedicated_bandwidth'):
        base='P06' if needs.get('high_bandwidth') else 'P05'
    elif needs.get('high_bandwidth'): base='P03'
    for site in profile['sites']:
        sid=site['site_id']
        add(base,1,'Dedicated bandwidth for business-critical operations.' if base in ['P05','P06'] else 'Primary connectivity for this location.',sid)
        if not any(i.get('site_id')==sid for i in items):
            add('P02' if segment!='micro' else 'P01',1,'Interim broadband option; dedicated service needs eligibility/assisted assessment.',sid)
        if resilience or segment in ['multi','manufacturing']:
            add('P09',1,'Keep billing and operations online if the primary link fails.',sid)
        if segment=='multi': add('P10',1,'Manage connectivity and application priorities across branches.',sid)
        if segment=='manufacturing' or needs.get('firewall'): add('P21',1,'Managed network protection for business systems.',sid)
        cameras=needs.get('cameras_per_site')
        if cameras is None and segment=='multi':
            cameras=1;assumptions.append('One camera per location is a provisional starting quantity; confirm coverage.')
        add('P23',cameras or 0,'Remote visibility and cloud recording; confirm camera coverage.',sid)
        if needs.get('guest_wifi'): add('P22',1,'Separate customer Wi-Fi from business traffic.',sid)
        if needs.get('static_ip'): add('P11',1,'Fixed address for approved remote access or servers.',sid)
        if needs.get('phone_channels'): add('P12',needs['phone_channels'],'Handle business calls and routing.',sid)
    retail=segment in ['micro','multi'] and any(x in business_type.casefold() for x in ['kirana','shop','retail','store','restaurant','दुकान'])
    counters=needs.get('pos_counters')
    if counters is None and retail:
        counters=len(profile['sites']);assumptions.append('One POS counter per location is provisional; confirm counters and existing POS.')
    if 'pos' in setup and needs.get('pos_counters') is None:
        counters=0;questions.append('You already have POS: retain it, or replace it with integrated billing?')
    add('P19',counters or 0,'Billing, stock management and UPI/card acceptance in the catalogue POS package.')
    if needs.get('whatsapp') or retail: add('P15',1,'Customer enquiries and a business messaging catalogue; active GST required.')
    add('P16',email_users,'Business email accounts for the confirmed users.')
    add('P20',devices,'Protect the confirmed work devices against malware.')
    quantities={'P07':'mobile_lines','P08':'premium_mobile_lines','P13':'tollfree_numbers','P14':'sms_packs','P17':'backup_accounts','P18':'websites','P24':'machines','P25':'vehicles'}
    for pid,field in quantities.items(): add(pid,needs.get(field,0),CATALOGUE[pid]['description'])
    if segment=='manufacturing' and not needs.get('machines'):
        questions.append('How many machines need uptime or energy monitoring? IoT is priced per device; no count is assumed.')
        deferred.append({'product_id':'P24','reason':'Machine monitoring option','requirements':['Confirm machine count and active GST registration']})
    if not email_users and segment=='professional': questions.append('How many people need a business email account? Keep existing paid email if suitable.')
    if not devices and segment in ['professional','manufacturing']: questions.append('How many work devices need security protection?')
    if 'business internet' in setup or 'leased' in setup:
        questions.append('When does the existing internet contract end, and should the new link replace it or provide backup?')
    if not current_setup: questions.append('What internet, billing and communication tools do you already use?')
    if needs.get('fibre_available') is None: questions.append('Is fibre available at each location? If not, consider AirFiber subject to coverage.')
    result=calculate(profile,items)
    alternatives=[]
    if any(i['product_id']=='P02' for i in items):
        cheaper=[{**x,'product_id':'P01'} if x['product_id']=='P02' else x.copy() for x in items]
        alternative=calculate(profile,cheaper)
        if alternative['valid']: alternatives.append({'label':'Lower-speed alternative (100 Mbps instead of 300 Mbps)','items':cheaper,'quote':alternative})
    explanation=' '.join(dict.fromkeys(r['reason'] for r in reasons))
    if current_setup: explanation+=' Current setup: '+current_setup+'. Confirm migration and avoid paying twice for retained tools.'
    if language=='hi': explanation='आपके व्यवसाय के लिए चुनी गई सेवाएँ; कृपया मात्रा और मौजूदा सेवाओं की पुष्टि करें। '+explanation
    return {'mode':'rules_based','segment':segment,'items':items,'quote':result,'explanation':explanation,'reasons':reasons,'follow_up_questions':questions,'assumptions':list(dict.fromkeys(assumptions)),'deferred_products':list({json.dumps(x,sort_keys=True):x for x in deferred}.values()),'over_budget':result['valid'] and budget is not None and result['estimated_total_inr']>budget,'alternatives':alternatives,'handoff_suggested':bool(deferred) or segment in ['multi','manufacturing'],'limitations':'Provisional quantities require confirmation. Coverage, migration and signing authority are not inferred.'}
